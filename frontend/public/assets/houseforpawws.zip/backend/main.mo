import Map "mo:core/Map";
import Array "mo:core/Array";
import Text "mo:core/Text";
import Time "mo:core/Time";
import Nat "mo:core/Nat";
import Storage "blob-storage/Storage";
import Iter "mo:core/Iter";
import Principal "mo:core/Principal";
import Runtime "mo:core/Runtime";
import MixinStorage "blob-storage/Mixin";
import MixinAuthorization "authorization/MixinAuthorization";
import AccessControl "authorization/access-control";

actor {
  include MixinStorage();
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  public type UserProfile = {
    displayName : Text;
    name : Text;
    email : Text;
    phone : Text;
    address : Text;
    tosAgreementVersion : ?Nat;
    tosAcceptedAt : ?Time.Time;
  };

  type PetId = Text;
  type ApplicationId = Text;
  type InquiryId = Text;
  type MessageId = Nat;
  type TOSAcceptanceId = Nat;

  type PetStatus = {
    #available;
    #adopted;
    #pending;
  };

  public type PetProfile = {
    id : PetId;
    name : Text;
    petType : Text;
    age : Nat;
    breed : Text;
    size : Text;
    description : Text;
    location : Text;
    photos : [Storage.ExternalBlob];
    medicalHistory : Text;
    status : PetStatus;
    createdAt : Time.Time;
    creator : ?Principal;
    owner : ?Principal;
    isHidden : Bool;
  };

  public type AdopterInfo = {
    displayName : Text;
    name : Text;
    email : Text;
    phone : Text;
    address : Text;
    preferences : Text;
  };

  public type AdoptionApplication = {
    id : ApplicationId;
    petId : PetId;
    adopter : AdopterInfo;
    message : Text;
    status : Text;
    submittedAt : Time.Time;
    submittedBy : Principal;
  };

  public type InquiryMessage = {
    id : InquiryId;
    petId : PetId;
    senderDisplayName : Text;
    senderName : Text;
    senderEmail : Text;
    message : Text;
    createdAt : Time.Time;
    submittedBy : Principal;
  };

  public type MessageStatus = {
    sent : ?Time.Time;
    delivered : ?Time.Time;
    read : ?Time.Time;
  };

  public type ChatMessage = {
    id : MessageId;
    sender : Principal;
    receiver : Principal;
    content : Text;
    timestamp : Time.Time;
    senderDisplayName : Text;
    receiverDisplayName : Text;
    status : MessageStatus;
  };

  public type MessageThread = {
    participants : [Principal];
    lastMessage : ?ChatMessage;
  };

  public type AdminDashboardStats = {
    totalPets : Nat;
    availablePets : Nat;
    pendingPets : Nat;
    adoptedPets : Nat;
    totalTOSAcceptedUsers : Nat;
    userAnalytics : [UserAnalytics];
    totalApplications : Nat;
    totalInquiries : Nat;
    totalMessages : Nat;
  };

  public type UserAnalytics = {
    email : Text;
    fullName : Text;
    displayName : Text;
    userType : Text;
  };

  public type TOSAcceptanceRecord = {
    id : TOSAcceptanceId;
    userId : Principal;
    acceptedAt : Time.Time;
    termsVersion : Nat;
  };

  type VerificationStatus = {
    hasCompletedCaptcha : Bool;
    tosAgreementVersion : ?Nat;
    tosAcceptedAt : ?Time.Time;
  };

  let userProfiles = Map.empty<Principal, UserProfile>();
  let pets = Map.empty<PetId, PetProfile>();
  let applications = Map.empty<ApplicationId, AdoptionApplication>();
  let inquiries = Map.empty<InquiryId, InquiryMessage>();
  let messages = Map.empty<MessageId, ChatMessage>();
  let tosAcceptedUsers = Map.empty<Principal, ()>();
  let tosAcceptanceHistory = Map.empty<TOSAcceptanceId, TOSAcceptanceRecord>();
  let verificationStatuses = Map.empty<Principal, VerificationStatus>();
  var nextMessageId = 1;
  var nextTOSAcceptanceId = 1;

  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can access profiles");
    };
    userProfiles.get(caller);
  };

  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    if (caller != user and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Can only view your own profile");
    };
    userProfiles.get(user);
  };

  public query ({ caller }) func getUserDisplayName(user : Principal) : async Text {
    switch (userProfiles.get(user)) {
      case (null) { "User" };
      case (?profile) {
        if (profile.displayName == "") { "User" } else { profile.displayName };
      };
    };
  };

  public shared ({ caller }) func saveCallerUserProfile(displayName : Text, name : Text, email : Text, phone : Text, address : Text) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };

    let updatedProfile = switch (userProfiles.get(caller)) {
      case (null) {
        {
          displayName;
          name;
          email;
          phone;
          address;
          tosAgreementVersion = null;
          tosAcceptedAt = null;
        };
      };
      case (?existingProfile) {
        {
          displayName;
          name;
          email;
          phone;
          address;
          tosAgreementVersion = existingProfile.tosAgreementVersion;
          tosAcceptedAt = existingProfile.tosAcceptedAt;
        };
      };
    };

    userProfiles.add(caller, updatedProfile);
  };

  public shared ({ caller }) func completeCaptcha() : async () {
    // CAPTCHA completion can happen during login/signup, so we allow any caller (including guests)
    // The caller is still authenticated by the IC, just may not have user role yet
    let userVerification = switch (verificationStatuses.get(caller)) {
      case (null) {
        { hasCompletedCaptcha = true; tosAgreementVersion = null; tosAcceptedAt = null };
      };
      case (?existingVerification) {
        { existingVerification with hasCompletedCaptcha = true };
      };
    };

    verificationStatuses.add(caller, userVerification);
  };

  public shared ({ caller }) func acceptTOS(termsVersion : Nat) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can accept Terms of Service");
    };

    let tosAcceptedAt = ?Time.now();

    verificationStatuses.add(caller, {
      hasCompletedCaptcha = true;
      tosAgreementVersion = ?termsVersion;
      tosAcceptedAt;
    });

    let updatedProfile = switch (userProfiles.get(caller)) {
      case (null) {
        {
          displayName = "";
          name = "";
          email = "";
          phone = "";
          address = "";
          tosAgreementVersion = ?termsVersion;
          tosAcceptedAt;
        };
      };
      case (?existingProfile) {
        {
          existingProfile with
          tosAgreementVersion = ?termsVersion;
          tosAcceptedAt;
        };
      };
    };

    userProfiles.add(caller, updatedProfile);
    tosAcceptedUsers.add(caller, ());
  };

  func hasCompletedVerification(caller : Principal) : Bool {
    switch (verificationStatuses.get(caller)) {
      case (null) { false };
      case (?status) {
        switch (userProfiles.get(caller)) {
          case (null) { false };
          case (?profile) {
            status.hasCompletedCaptcha and
            status.tosAgreementVersion.isSome() and
            status.tosAcceptedAt.isSome() and
            profile.displayName != "";
          };
        };
      };
    };
  };

  public query ({ caller }) func canUsePlatformFeatures() : async Bool {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      return false;
    };
    hasCompletedVerification(caller);
  };

  public query ({ caller }) func canUploadPets() : async Bool {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      return false;
    };
    hasCompletedVerification(caller);
  };

  public query ({ caller }) func isPetOwner(petId : PetId) : async Bool {
    let pet = switch (pets.get(petId)) {
      case (null) { return false };
      case (?p) { p };
    };
    switch (pet.owner) {
      case (?owner) { owner == caller };
      case (null) { false };
    };
  };

  public shared ({ caller }) func addPet(pet : PetProfile) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can add pets");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before uploading pets");
    };

    let petWithOwner = { pet with creator = ?caller; owner = ?caller; isHidden = false };
    pets.add(pet.id, petWithOwner);
  };

  public shared ({ caller }) func updatePet(petId : PetId, updatedPet : PetProfile) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can update pets");
    };

    let existingPet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    let isOwner = ?caller == existingPet.owner;
    let isCreator = ?caller == existingPet.creator;

    if (not isOwner and not isCreator) {
      Runtime.trap("Unauthorized: You can only update your own pets");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before updating pets");
    };

    let petWithOwner = {
      existingPet with
      name = updatedPet.name;
      petType = updatedPet.petType;
      age = updatedPet.age;
      breed = updatedPet.breed;
      size = updatedPet.size;
      description = updatedPet.description;
      location = updatedPet.location;
      photos = updatedPet.photos;
      medicalHistory = updatedPet.medicalHistory;
      status = updatedPet.status;
    };
    pets.add(petId, petWithOwner);
  };

  public shared ({ caller }) func removePet(petId : PetId) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can remove pets");
    };

    let existingPet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    let isOwner = ?caller == existingPet.owner;
    let isCreator = ?caller == existingPet.creator;

    if (not isOwner and not isCreator) {
      Runtime.trap("Unauthorized: You can only remove your own pets");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before removing pets");
    };

    pets.remove(petId);
  };

  public shared ({ caller }) func deleteListing(petId : PetId) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only authenticated users can delete listings");
    };

    let pet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    if (pet.owner != ?caller and pet.creator != ?caller) {
      Runtime.trap("Unauthorized: Only the owner or creator can delete this listing");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before deleting listings");
    };

    pets.remove(petId);
  };

  public query ({ caller }) func getPet(petId : PetId) : async PetProfile {
    let pet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    if (pet.isHidden and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Pet not found");
    };
    pet;
  };

  public query ({ caller }) func getAvailablePets() : async [PetProfile] {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    pets.values().toArray().filter(
      func(pet) {
        pet.status == #available and (isAdmin or not pet.isHidden)
      }
    );
  };

  public query ({ caller }) func searchPetsByType(petType : Text) : async [PetProfile] {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    pets.values().toArray().filter(
      func(pet) {
        Text.equal(pet.petType, petType) and (isAdmin or not pet.isHidden)
      }
    );
  };

  public query ({ caller }) func filterPetsByAge(minAge : Nat, maxAge : Nat) : async [PetProfile] {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    pets.values().toArray().filter(
      func(pet) {
        pet.age >= minAge and pet.age <= maxAge and (isAdmin or not pet.isHidden)
      }
    );
  };

  public query ({ caller }) func filterPetsByBreed(breed : Text) : async [PetProfile] {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    pets.values().toArray().filter(
      func(pet) {
        Text.equal(pet.breed, breed) and (isAdmin or not pet.isHidden)
      }
    );
  };

  public query ({ caller }) func filterPetsByStatus(status : PetStatus) : async [PetProfile] {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    pets.values().toArray().filter(
      func(pet) {
        pet.status == status and (isAdmin or not pet.isHidden)
      }
    );
  };

  public shared ({ caller }) func submitApplication(application : AdoptionApplication) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can submit applications");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before submitting applications");
    };

    let pet = switch (pets.get(application.petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    let appWithCaller = { application with submittedBy = caller };
    applications.add(application.id, appWithCaller);

    pets.add(application.petId, { pet with status = #pending });

    let messageContent = "New adoption application for " # pet.name # ": " # application.message;
    let messageStatus : MessageStatus = {
      sent = ?Time.now();
      delivered = null;
      read = null;
    };
    let receiverDisplayName = switch (pet.owner) {
      case (null) { application.adopter.displayName };
      case (?owner) {
        switch (userProfiles.get(owner)) {
          case (null) { application.adopter.displayName };
          case (?profile) {
            if (profile.displayName == "") { application.adopter.displayName } else { profile.displayName };
          };
        };
      };
    };
    let message = {
      id = nextMessageId;
      sender = caller;
      receiver = switch (pet.owner) {
        case (null) { caller };
        case (?owner) { owner };
      };
      content = messageContent;
      timestamp = Time.now();
      senderDisplayName = application.adopter.displayName;
      receiverDisplayName;
      status = messageStatus;
    };
    messages.add(message.id, message);
    nextMessageId += 1;
  };

  public query ({ caller }) func getApplication(applicationId : ApplicationId) : async AdoptionApplication {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can view applications");
    };
    switch (applications.get(applicationId)) {
      case (null) { Runtime.trap("Application not found") };
      case (?app) {
        let pet = switch (pets.get(app.petId)) {
          case (null) { Runtime.trap("Pet not found") };
          case (?p) { p };
        };

        let isSubmitter = caller == app.submittedBy;
        let isOwner = pet.owner == ?caller;
        let isAdmin = AccessControl.isAdmin(accessControlState, caller);

        if (not isSubmitter and not isOwner and not isAdmin) {
          Runtime.trap("Unauthorized: Can only view your own applications or applications for your pets");
        };
        app;
      };
    };
  };

  public query ({ caller }) func getApplicationsByPet(petId : PetId) : async [AdoptionApplication] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can view applications");
    };

    let pet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    if (not AccessControl.isAdmin(accessControlState, caller) and pet.owner != ?caller) {
      Runtime.trap("Unauthorized: Only pet owners and admins can view applications for a pet");
    };

    applications.values().toArray().filter(func(app) { Text.equal(app.petId, petId) });
  };

  public query ({ caller }) func getAllApplications() : async [AdoptionApplication] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can view all applications");
    };
    applications.values().toArray();
  };

  public query ({ caller }) func getMyApplications() : async [AdoptionApplication] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can view their applications");
    };
    applications.values().toArray().filter(func(app) { app.submittedBy == caller });
  };

  public shared ({ caller }) func updateApplicationStatus(applicationId : ApplicationId, status : Text) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can update application status");
    };

    let app = switch (applications.get(applicationId)) {
      case (null) { Runtime.trap("Application not found") };
      case (?a) { a };
    };

    let pet = switch (pets.get(app.petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    if (not AccessControl.isAdmin(accessControlState, caller) and pet.owner != ?caller) {
      Runtime.trap("Unauthorized: Only pet owners and admins can update application status");
    };

    applications.add(applicationId, { app with status });
  };

  public shared ({ caller }) func markPetAdopted(petId : PetId) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can mark pets as adopted");
    };

    let pet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    if (not AccessControl.isAdmin(accessControlState, caller) and pet.owner != ?caller) {
      Runtime.trap("Unauthorized: Only pet owners and admins can mark pets as adopted");
    };

    pets.add(petId, { pet with status = #adopted });
  };

  public shared ({ caller }) func submitInquiry(inquiry : InquiryMessage) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can submit inquiries");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before submitting inquiries");
    };

    let pet = switch (pets.get(inquiry.petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    let inquiryWithCaller = { inquiry with submittedBy = caller };
    inquiries.add(inquiry.id, inquiryWithCaller);

    let messageContent = "New inquiry about " # pet.name # ": " # inquiry.message;
    let messageStatus : MessageStatus = {
      sent = ?Time.now();
      delivered = null;
      read = null;
    };
    let receiverDisplayName = switch (pet.owner) {
      case (null) { inquiry.senderDisplayName };
      case (?owner) {
        switch (userProfiles.get(owner)) {
          case (null) { inquiry.senderDisplayName };
          case (?profile) {
            if (profile.displayName == "") { inquiry.senderDisplayName } else { profile.displayName };
          };
        };
      };
    };
    let message = {
      id = nextMessageId;
      sender = caller;
      receiver = switch (pet.owner) {
        case (null) { caller };
        case (?owner) { owner };
      };
      content = messageContent;
      timestamp = Time.now();
      senderDisplayName = inquiry.senderDisplayName;
      receiverDisplayName;
      status = messageStatus;
    };
    messages.add(message.id, message);
    nextMessageId += 1;
  };

  public query ({ caller }) func getInquiriesForPet(petId : PetId) : async [InquiryMessage] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can view inquiries");
    };

    let pet = switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?p) { p };
    };

    if (not AccessControl.isAdmin(accessControlState, caller) and pet.owner != ?caller) {
      Runtime.trap("Unauthorized: Only pet owners and admins can view inquiries for a pet");
    };

    inquiries.values().toArray().filter(func(inq) { Text.equal(inq.petId, petId) });
  };

  public query ({ caller }) func getAllInquiries() : async [InquiryMessage] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can view all inquiries");
    };
    inquiries.values().toArray();
  };

  public query ({ caller }) func getMyInquiries() : async [InquiryMessage] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can view their inquiries");
    };
    inquiries.values().toArray().filter(func(inq) { inq.submittedBy == caller });
  };

  public shared ({ caller }) func sendMessage(receiver : Principal, content : Text) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can send messages");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before sending messages");
    };

    let senderDisplayName = switch (userProfiles.get(caller)) {
      case (null) { "User" };
      case (?profile) {
        if (profile.displayName == "") { "User" } else { profile.displayName };
      };
    };

    let receiverDisplayName = switch (userProfiles.get(receiver)) {
      case (null) { "User" };
      case (?profile) {
        if (profile.displayName == "") { "User" } else { profile.displayName };
      };
    };

    let messageStatus : MessageStatus = {
      sent = ?Time.now();
      delivered = null;
      read = null;
    };

    let message = {
      id = nextMessageId;
      sender = caller;
      receiver;
      content;
      timestamp = Time.now();
      senderDisplayName;
      receiverDisplayName;
      status = messageStatus;
    };

    messages.add(message.id, message);
    nextMessageId += 1;
  };

  public query ({ caller }) func getMessagesWithUser(otherUser : Principal) : async [ChatMessage] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can access messages");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before accessing messages");
    };

    messages.values().toArray().filter(
      func(msg) {
        (msg.sender == caller and msg.receiver == otherUser) or (msg.sender == otherUser and msg.receiver == caller);
      }
    );
  };

  public query ({ caller }) func getInbox() : async [MessageThread] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can access inbox");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before accessing inbox");
    };

    let allMessages = messages.values().toArray();

    let participantsMap = Map.empty<Principal, ChatMessage>();

    for (message in allMessages.values()) {
      let counterparty = if (message.sender == caller) { message.receiver } else if (message.receiver == caller) {
        message.sender;
      } else { message.sender };

      switch (participantsMap.get(counterparty)) {
        case (?existing) {
          if (message.timestamp > existing.timestamp) {
            participantsMap.add(counterparty, message);
          };
        };
        case (null) {
          participantsMap.add(counterparty, message);
        };
      };
    };

    let threads = participantsMap.entries().toArray().map(
      func((otherUser, lastMessage)) {
        {
          participants = [caller, otherUser];
          lastMessage = ?lastMessage;
        };
      }
    );
    threads;
  };

  public query ({ caller }) func getAllMessagesWithUser(otherUser : Principal) : async [ChatMessage] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can access messages");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before accessing messages");
    };

    messages.values().toArray().filter(
      func(msg) {
        (msg.sender == caller and msg.receiver == otherUser) or (msg.sender == otherUser and msg.receiver == caller);
      }
    );
  };

  public query ({ caller }) func getInboxWithDisplayNames() : async [(Principal, ?Text)] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can access inbox display names");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before accessing inbox");
    };

    let allMessages = messages.values().toArray();
    let participantsMap = Map.empty<Principal, ChatMessage>();

    for (message in allMessages.values()) {
      if (message.sender == caller) {
        let counterparty = message.receiver;
        switch (participantsMap.get(counterparty)) {
          case (?existing) {
            if (message.timestamp > existing.timestamp) {
              participantsMap.add(counterparty, message);
            };
          };
          case (null) {
            participantsMap.add(counterparty, message);
          };
        };
      } else if (message.receiver == caller) {
        let counterparty = message.sender;
        switch (participantsMap.get(counterparty)) {
          case (?existing) {
            if (message.timestamp > existing.timestamp) {
              participantsMap.add(counterparty, message);
            };
          };
          case (null) {
            participantsMap.add(counterparty, message);
          };
        };
      };
    };

    let participants = participantsMap.keys().toArray();
    participants.map(
      func(participant) {
        let displayName = switch (userProfiles.get(participant)) {
          case (null) { null };
          case (?profile) {
            if (profile.displayName == "") { null } else { ?profile.displayName };
          };
        };
        (participant, displayName);
      }
    );
  };

  public query ({ caller }) func getMessageWithParticipantNames(messageId : MessageId) : async ?ChatMessage {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can access message participants");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before accessing messages");
    };

    let message = switch (messages.get(messageId)) {
      case (null) { return null };
      case (?msg) { msg };
    };

    if (message.sender != caller and message.receiver != caller) {
      Runtime.trap("Unauthorized: You can only view messages you are a participant in");
    };

    ?message;
  };

  public shared ({ caller }) func markMessagesAsRead(sender : Principal) : async Nat {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can mark messages as read");
    };

    if (not hasCompletedVerification(caller)) {
      Runtime.trap("You must accept the Terms of Service, pass the CAPTCHA, and set a display name before marking messages as read");
    };

    let currentTime = ?Time.now();
    var updatedCount = 0;

    let newEntries : [(MessageId, ChatMessage)] = messages.toArray().map(
      func((id, msg)) {
        if (msg.sender == sender and msg.receiver == caller and msg.status.read == null) {
          updatedCount += 1;
          (id, { msg with status = { msg.status with read = currentTime } });
        } else {
          (id, msg);
        };
      }
    );

    for ((id, updatedMsg) in newEntries.values()) {
      messages.add(id, updatedMsg);
    };

    updatedCount;
  };

  public query ({ caller }) func getAdminDashboardStats() : async AdminDashboardStats {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can access the admin dashboard");
    };

    let totalPets = pets.size();

    let availablePets = pets.values().toArray().filter(func(pet) { pet.status == #available }).size();

    let pendingPets = pets.values().toArray().filter(func(pet) { pet.status == #pending }).size();

    let adoptedPets = pets.values().toArray().filter(func(pet) { pet.status == #adopted }).size();

    let tosAcceptedUsers = userProfiles.values().toArray().filter(func(profile) { profile.tosAgreementVersion.isSome() and profile.tosAcceptedAt.isSome() });
    let totalTOSAcceptedUsers = tosAcceptedUsers.size();

    let totalApplications = applications.size();

    let totalInquiries = inquiries.size();

    let totalMessages = messages.size();

    let userAnalytics = tosAcceptedUsers.map(
      func(profile) {
        let userType = if (hasSubmittedApplications(profile.email)) {
          "Adopting";
        } else if (hasListedPets(profile.email)) { "Putting for Adoption" } else {
          "Unknown";
        };

        {
          email = profile.email;
          fullName = profile.name;
          displayName = profile.displayName;
          userType;
        };
      }
    );

    {
      totalPets;
      availablePets;
      pendingPets;
      adoptedPets;
      totalTOSAcceptedUsers;
      userAnalytics;
      totalApplications;
      totalInquiries;
      totalMessages;
    };
  };

  func hasSubmittedApplications(email : Text) : Bool {
    let apps = applications.values().toArray();
    for (app in apps.values()) {
      if (app.adopter.email == email) {
        return true;
      };
    };
    false;
  };

  func hasListedPets(email : Text) : Bool {
    let petsArray = pets.values().toArray();
    for (pet in petsArray.values()) {
      switch (pet.creator) {
        case (?creator) {
          switch (userProfiles.get(creator)) {
            case (?profile) { if (profile.email == email) { return true } };
            case (null) {};
          };
        };
        case (null) {};
      };

      switch (pet.owner) {
        case (?owner) {
          switch (userProfiles.get(owner)) {
            case (?profile) { if (profile.email == email) { return true } };
            case (null) {};
          };
        };
        case (null) {};
      };
    };
    false;
  };

  public query ({ caller }) func getTOSAcceptedUserEmails() : async [Text] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can access TOS accepted user emails");
    };

    userProfiles.values().toArray().filter(func(profile) { profile.tosAgreementVersion.isSome() and profile.tosAcceptedAt.isSome() }).map(func(profile) { profile.email });
  };

  public shared ({ caller }) func recordTOSAcceptance(termsVersion : Nat) : async TOSAcceptanceId {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only users can accept Terms of Service");
    };

    let id = nextTOSAcceptanceId;
    tosAcceptanceHistory.add(
      id,
      {
        id;
        userId = caller;
        acceptedAt = Time.now();
        termsVersion;
      },
    );
    nextTOSAcceptanceId += 1;
    id;
  };

  public query ({ caller }) func getAllTOSAcceptanceRecords() : async [TOSAcceptanceRecord] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can access all TOS acceptance records");
    };

    tosAcceptanceHistory.values().toArray();
  };

  public query ({ caller }) func getUserListings(user : Principal) : async [PetProfile] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only authenticated users can access listings");
    };

    if (caller != user and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: You can only view your own listings");
    };

    let userListings = pets.values().toArray().filter(
      func(pet) {
        switch (pet.creator) {
          case (?creator) { creator == user };
          case (null) { false };
        };
      }
    );
    userListings;
  };

  public shared ({ caller }) func adminUpdatePet(petId : PetId, updatedPet : PetProfile) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can moderate pets");
    };

    switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?_) {};
    };
    pets.add(petId, updatedPet);
  };

  public shared ({ caller }) func adminRemovePet(petId : PetId) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can remove pets");
    };

    switch (pets.get(petId)) {
      case (null) { Runtime.trap("Pet not found") };
      case (?_) { pets.remove(petId) };
    };
  };

  public query ({ caller }) func getPublicPets() : async [PetProfile] {
    let isAdmin = AccessControl.isAdmin(accessControlState, caller);
    pets.values().toArray().filter(func(pet) { isAdmin or not pet.isHidden });
  };
};
