import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface CaptchaModalProps {
  open: boolean;
  onClose: () => void;
  onVerified: () => void;
  title?: string;
  description?: string;
}

// Simple math CAPTCHA for human verification
function generateCaptcha(): { question: string; answer: number } {
  const num1 = Math.floor(Math.random() * 10) + 1;
  const num2 = Math.floor(Math.random() * 10) + 1;
  const operations = ['+', '-', '*'];
  const operation = operations[Math.floor(Math.random() * operations.length)];
  
  let answer: number;
  let question: string;
  
  switch (operation) {
    case '+':
      answer = num1 + num2;
      question = `${num1} + ${num2}`;
      break;
    case '-':
      answer = num1 - num2;
      question = `${num1} - ${num2}`;
      break;
    case '*':
      answer = num1 * num2;
      question = `${num1} × ${num2}`;
      break;
    default:
      answer = num1 + num2;
      question = `${num1} + ${num2}`;
  }
  
  return { question, answer };
}

export default function CaptchaModal({ 
  open, 
  onClose, 
  onVerified,
  title = "Human Verification",
  description = "Please solve this simple math problem to verify you're human."
}: CaptchaModalProps) {
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [userAnswer, setUserAnswer] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  useEffect(() => {
    if (open) {
      setCaptcha(generateCaptcha());
      setUserAnswer('');
    }
  }, [open]);

  const handleRefresh = () => {
    setCaptcha(generateCaptcha());
    setUserAnswer('');
  };

  const handleVerify = () => {
    setIsVerifying(true);
    
    const answer = parseInt(userAnswer, 10);
    
    if (isNaN(answer)) {
      toast.error('Please enter a valid number');
      setIsVerifying(false);
      return;
    }
    
    if (answer === captcha.answer) {
      toast.success('Verification successful!');
      setUserAnswer('');
      onVerified();
    } else {
      toast.error('Incorrect answer. Please try again.');
      handleRefresh();
    }
    
    setIsVerifying(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && userAnswer.trim()) {
      handleVerify();
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-md" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex items-center justify-center gap-4 rounded-lg border-2 border-dashed bg-muted/50 p-8">
            <div className="text-center">
              <p className="mb-2 text-sm text-muted-foreground">What is:</p>
              <p className="text-3xl font-bold">{captcha.question} = ?</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefresh}
              className="h-8 w-8"
              title="Generate new question"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="captcha-answer">Your Answer</Label>
            <Input
              id="captcha-answer"
              type="number"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Enter the answer"
              autoFocus
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isVerifying}>
            Cancel
          </Button>
          <Button 
            onClick={handleVerify} 
            disabled={!userAnswer.trim() || isVerifying}
          >
            {isVerifying ? 'Verifying...' : 'Verify'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
