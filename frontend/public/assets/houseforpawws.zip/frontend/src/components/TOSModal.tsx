import { useState } from 'react';
import { useAcceptTOS } from '../hooks/useQueries';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface TOSModalProps {
  open: boolean;
  onClose: () => void;
  onAccepted?: () => void;
}

export default function TOSModal({ open, onClose, onAccepted }: TOSModalProps) {
  const [hasAgreed, setHasAgreed] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const acceptTOS = useAcceptTOS();

  const handleAccept = async () => {
    if (!hasAgreed) {
      toast.error('Please agree to the Terms of Service to continue');
      return;
    }

    try {
      await acceptTOS.mutateAsync();
      setShowSuccess(true);
      toast.success('Terms of Service accepted successfully!');
      
      // Wait a moment to show success state, then close
      setTimeout(() => {
        setHasAgreed(false);
        setShowSuccess(false);
        if (onAccepted) {
          onAccepted();
        } else {
          onClose();
        }
      }, 1000);
    } catch (error: any) {
      console.error('TOS acceptance error:', error);
      const errorMessage = error?.message || 'Failed to accept Terms of Service. Please try again.';
      toast.error(errorMessage);
    }
  };

  const handleCancel = () => {
    if (!acceptTOS.isPending) {
      setHasAgreed(false);
      setShowSuccess(false);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && !acceptTOS.isPending && handleCancel()}>
      <DialogContent className="max-w-2xl" onInteractOutside={(e) => {
        if (acceptTOS.isPending) {
          e.preventDefault();
        }
      }}>
        <DialogHeader>
          <DialogTitle>Terms of Service</DialogTitle>
          <DialogDescription>
            Please read and accept our Terms of Service to continue using the platform. You must accept these terms after each login session.
          </DialogDescription>
        </DialogHeader>

        {showSuccess && (
          <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
            <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
            <AlertDescription className="text-green-800 dark:text-green-200">
              Terms of Service accepted successfully! Redirecting...
            </AlertDescription>
          </Alert>
        )}
        
        <ScrollArea className="h-[400px] rounded-md border p-4">
          <div className="space-y-4 text-sm">
            <section>
              <h3 className="mb-2 font-semibold">1. Acceptance of Terms</h3>
              <p className="text-muted-foreground">
                By using House for Pawws, you agree to comply with and be bound by these Terms of Service. 
                If you do not agree to these terms, please do not use our platform.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">2. Content Responsibility</h3>
              <p className="text-muted-foreground">
                You are solely responsible for all content you upload, including pet descriptions, photos, and information. 
                You warrant that all information provided is accurate, truthful, and does not violate any laws or third-party rights.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">3. Pet Welfare</h3>
              <p className="text-muted-foreground">
                You agree to prioritize the welfare and best interests of all animals listed on the platform. 
                All pets must be in good health, properly vaccinated, and legally available for adoption. 
                You must provide accurate medical history and behavioral information.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">4. Prohibited Content</h3>
              <p className="text-muted-foreground">
                You may not upload content that is false, misleading, defamatory, obscene, or violates any applicable laws. 
                You may not list animals that are endangered, protected by law, or obtained through illegal means.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">5. Intellectual Property</h3>
              <p className="text-muted-foreground">
                You retain ownership of the content you upload but grant House for Pawws a non-exclusive, worldwide license 
                to use, display, and distribute your content for the purpose of facilitating pet adoptions.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">6. Privacy and Data</h3>
              <p className="text-muted-foreground">
                We respect your privacy and handle all personal information in accordance with applicable data protection laws. 
                By using our platform, you consent to the collection and use of information as described in our Privacy Policy.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">7. Liability</h3>
              <p className="text-muted-foreground">
                House for Pawws acts as a platform to connect adopters with pets. We are not responsible for the accuracy 
                of listings, the condition of animals, or the outcome of adoptions. Users engage with the platform at their own risk.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">8. Termination</h3>
              <p className="text-muted-foreground">
                We reserve the right to remove any content or terminate access to users who violate these terms, 
                engage in fraudulent activity, or misuse the platform.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">9. Changes to Terms</h3>
              <p className="text-muted-foreground">
                We may update these Terms of Service from time to time. Continued use of the platform after changes 
                constitutes acceptance of the updated terms.
              </p>
            </section>

            <section>
              <h3 className="mb-2 font-semibold">10. Contact</h3>
              <p className="text-muted-foreground">
                If you have questions about these Terms of Service, please contact us through the platform.
              </p>
            </section>
          </div>
        </ScrollArea>

        <div className="flex items-center space-x-2">
          <Checkbox 
            id="tos-agreement" 
            checked={hasAgreed} 
            onCheckedChange={(checked) => setHasAgreed(checked === true)}
            disabled={acceptTOS.isPending || showSuccess}
          />
          <Label htmlFor="tos-agreement" className="text-sm font-normal cursor-pointer">
            I have read and agree to the Terms of Service
          </Label>
        </div>

        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={handleCancel} 
            disabled={acceptTOS.isPending || showSuccess}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleAccept} 
            disabled={!hasAgreed || acceptTOS.isPending || showSuccess}
            className="min-w-[140px]"
          >
            {acceptTOS.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Accepting...
              </>
            ) : showSuccess ? (
              <>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Accepted!
              </>
            ) : (
              'Accept and Continue'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
