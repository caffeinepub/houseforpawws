import { useState, useEffect } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface BreederWarningModalProps {
  open: boolean;
  onClose: () => void;
}

export default function BreederWarningModal({ open, onClose }: BreederWarningModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md border-2 border-destructive/20 bg-gradient-to-br from-background to-destructive/5">
        <DialogHeader>
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
            <AlertTriangle className="h-8 w-8 text-destructive" />
          </div>
          <DialogTitle className="text-center text-xl">Be Careful for Breeders</DialogTitle>
          <DialogDescription className="text-center text-base">
            Important reminder about adoption safety
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4">
            <p className="text-sm font-medium text-foreground">
              <strong className="text-destructive">⚠️ Never pay for adoptions!</strong>
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Legitimate pet adoptions should not require payment. If someone asks you to pay for a pet, they might be a breeder or scammer.
            </p>
          </div>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p className="font-medium text-foreground">Stay safe by:</p>
            <ul className="ml-4 list-disc space-y-1">
              <li>Meeting the pet in person before committing</li>
              <li>Verifying the legitimacy of the adoption organization</li>
              <li>Asking for veterinary records and documentation</li>
              <li>Being cautious of requests for money transfers</li>
            </ul>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={onClose} className="w-full">
            I Understand
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
