import { SiInstagram } from 'react-icons/si';

export default function Footer() {
  return (
    <footer className="border-t bg-gradient-to-br from-primary/5 via-chart-1/5 to-chart-2/5">
      <div className="container py-8">
        <div className="flex flex-col items-center justify-center gap-4 text-center">
          <p className="text-sm text-muted-foreground">
            Built by Bhavya Jotwani — this is a student-based initiative.
          </p>
          <div className="flex items-center gap-2">
            <a
              href="https://www.instagram.com/houseforpawws/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary/10 via-chart-1/10 to-chart-2/10 px-4 py-2 text-sm font-medium text-primary transition-all hover:from-primary/20 hover:via-chart-1/20 hover:to-chart-2/20 hover:shadow-md"
              aria-label="Follow us on Instagram"
            >
              <SiInstagram className="h-4 w-4" />
              <span>Follow us on Instagram</span>
            </a>
          </div>
          <p className="text-xs text-muted-foreground">
            Every pet deserves a loving home. Thank you for considering adoption.
          </p>
        </div>
      </div>
    </footer>
  );
}

