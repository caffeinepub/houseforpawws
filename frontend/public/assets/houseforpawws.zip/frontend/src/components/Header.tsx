import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { useIsCallerAdmin, useGetCallerUserProfile } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { PawPrint, User, Shield, UserCircle, Settings, LogOut, MessageCircle, BarChart3, Edit3, ShieldCheck, Home } from 'lucide-react';
import { useState } from 'react';
import CaptchaModal from './CaptchaModal';
import type { View } from '../App';

interface HeaderProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export default function Header({ currentView, onNavigate }: HeaderProps) {
  const { login, clear, loginStatus, identity } = useInternetIdentity();
  const { data: isAdmin } = useIsCallerAdmin();
  const { data: userProfile } = useGetCallerUserProfile();
  const queryClient = useQueryClient();

  const [showCaptcha, setShowCaptcha] = useState(false);

  const isAuthenticated = !!identity;
  const disabled = loginStatus === 'logging-in';
  const buttonText = loginStatus === 'logging-in' ? 'Logging in...' : 'Login';

  const handleLoginClick = () => {
    setShowCaptcha(true);
  };

  const handleCaptchaVerified = async () => {
    setShowCaptcha(false);
    try {
      await login();
    } catch (error: any) {
      console.error('Login error:', error);
      if (error.message === 'User is already authenticated') {
        await clear();
        setTimeout(() => login(), 300);
      }
    }
  };

  const handleLogout = async () => {
    await clear();
    queryClient.clear();
    onNavigate('home');
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-gradient-to-r from-background via-background to-primary/5 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 text-xl font-bold transition-colors hover:text-primary"
            >
              <PawPrint className="h-7 w-7 text-primary" />
              <span className="bg-gradient-to-r from-primary via-chart-1 to-primary bg-clip-text text-transparent">
                House for Pawws
              </span>
            </button>
            <Button
              variant={currentView === 'home' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onNavigate('home')}
              className="gap-2"
            >
              <Home className="h-4 w-4" />
              Home
            </Button>
          </div>

          <nav className="flex items-center gap-2">
            {isAuthenticated ? (
              <>
                <Button
                  variant={currentView === 'my-applications' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => onNavigate('my-applications')}
                  className="gap-2"
                >
                  <User className="h-4 w-4" />
                  My Applications
                </Button>
                <Button
                  variant={currentView === 'inbox' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => onNavigate('inbox')}
                  className="gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  Messages
                </Button>
                {isAdmin && (
                  <>
                    <Button
                      variant={currentView === 'admin' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => onNavigate('admin')}
                      className="gap-2"
                    >
                      <Shield className="h-4 w-4" />
                      Admin
                    </Button>
                    <Button
                      variant={currentView === 'admin-analytics' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => onNavigate('admin-analytics')}
                      className="gap-2"
                    >
                      <BarChart3 className="h-4 w-4" />
                      Dashboard
                    </Button>
                    <Button
                      variant={currentView === 'admin-moderation' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => onNavigate('admin-moderation')}
                      className="gap-2"
                    >
                      <ShieldCheck className="h-4 w-4" />
                      Moderate
                    </Button>
                  </>
                )}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="relative h-9 w-9 rounded-full">
                      <Avatar className="h-9 w-9">
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {userProfile?.name ? getInitials(userProfile.name) : <UserCircle className="h-5 w-5" />}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    {userProfile?.name && (
                      <>
                        <div className="flex flex-col space-y-1 px-2 py-1.5">
                          <p className="text-sm font-medium leading-none">{userProfile.name}</p>
                          {userProfile.email && (
                            <p className="text-xs leading-none text-muted-foreground">{userProfile.email}</p>
                          )}
                        </div>
                        <DropdownMenuSeparator />
                      </>
                    )}
                    <DropdownMenuItem onClick={() => onNavigate('view-profile')} className="cursor-pointer">
                      <UserCircle className="mr-2 h-4 w-4" />
                      <span>View Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onNavigate('edit-profile')} className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      <span>Edit Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onNavigate('edit-listings')} className="cursor-pointer">
                      <Edit3 className="mr-2 h-4 w-4" />
                      <span>Edit Your Listings</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onNavigate('settings')} className="cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Logout</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button onClick={handleLoginClick} disabled={disabled} variant="default">
                {buttonText}
              </Button>
            )}
          </nav>
        </div>
      </header>

      <CaptchaModal
        open={showCaptcha}
        onClose={() => setShowCaptcha(false)}
        onVerified={handleCaptchaVerified}
        title="Login Verification"
        description="Please complete this verification to log in."
      />
    </>
  );
}
