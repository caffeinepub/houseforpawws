import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import type {
  PetProfile,
  AdoptionApplication,
  InquiryMessage,
  UserProfile,
  PetStatus,
  ApplicationId,
  PetId,
  InquiryId,
  MessageThread,
  ChatMessage,
  AdminDashboardStats,
} from '../backend';
import type { Principal } from '@icp-sdk/core/principal';

// User Profile Queries
export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
    staleTime: 0,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useGetUserProfile(user: Principal | null) {
  const { actor, isFetching } = useActor();

  return useQuery<UserProfile | null>({
    queryKey: ['userProfile', user?.toString()],
    queryFn: async () => {
      if (!actor || !user) return null;
      return actor.getUserProfile(user);
    },
    enabled: !!actor && !isFetching && !!user,
  });
}

export function useGetUserDisplayName(user: Principal | null) {
  const { actor, isFetching } = useActor();

  return useQuery<string>({
    queryKey: ['userDisplayName', user?.toString()],
    queryFn: async () => {
      if (!actor || !user) return 'User';
      return actor.getUserDisplayName(user);
    },
    enabled: !!actor && !isFetching && !!user,
    staleTime: 60000, // Cache for 1 minute
  });
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(
        profile.displayName,
        profile.name,
        profile.email,
        profile.phone,
        profile.address
      );
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      await queryClient.refetchQueries({ queryKey: ['currentUserProfile'] });
      await queryClient.invalidateQueries({ queryKey: ['canUsePlatformFeatures'] });
      await queryClient.invalidateQueries({ queryKey: ['userDisplayName'] });
    },
  });
}

export function useIsCallerAdmin() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

// Terms of Service Queries
export function useAcceptTOS() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      // Pass termsVersion = 1 as required by backend
      await actor.acceptTOS(BigInt(1));
      
      // Wait a moment for backend state to settle
      await new Promise(resolve => setTimeout(resolve, 500));
    },
    onSuccess: async () => {
      // Invalidate and refetch all related queries to ensure UI is in sync
      await queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      await queryClient.invalidateQueries({ queryKey: ['canUsePlatformFeatures'] });
      
      // Force refetch to get updated data
      await queryClient.refetchQueries({ queryKey: ['currentUserProfile'] });
      await queryClient.refetchQueries({ queryKey: ['canUsePlatformFeatures'] });
    },
    retry: 1,
    retryDelay: 1000,
  });
}

// Platform Features Check (TOS + Display Name + CAPTCHA)
export function useCanUsePlatformFeatures() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['canUsePlatformFeatures'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.canUsePlatformFeatures();
    },
    enabled: !!actor && !isFetching,
    staleTime: 0,
    retry: 2,
  });
}

// Pet ownership check
export function useIsPetOwner(petId: PetId | null) {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isPetOwner', petId],
    queryFn: async () => {
      if (!actor || !petId) return false;
      return actor.isPetOwner(petId);
    },
    enabled: !!actor && !isFetching && !!petId,
  });
}

// Pet Queries - Public access (no authentication required for browsing)
export function useGetAvailablePets() {
  const { actor, isFetching } = useActor();

  return useQuery<PetProfile[]>({
    queryKey: ['availablePets'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAvailablePets();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetPublicPets() {
  const { actor, isFetching } = useActor();

  return useQuery<PetProfile[]>({
    queryKey: ['publicPets'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPublicPets();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetPet(petId: PetId) {
  const { actor, isFetching } = useActor();

  return useQuery<PetProfile>({
    queryKey: ['pet', petId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getPet(petId);
    },
    enabled: !!actor && !isFetching && !!petId,
  });
}

export function useSearchPetsByType(petType: string) {
  const { actor, isFetching } = useActor();

  return useQuery<PetProfile[]>({
    queryKey: ['petsByType', petType],
    queryFn: async () => {
      if (!actor) return [];
      return actor.searchPetsByType(petType);
    },
    enabled: !!actor && !isFetching && !!petType,
  });
}

export function useFilterPetsByStatus(status: PetStatus) {
  const { actor, isFetching } = useActor();

  return useQuery<PetProfile[]>({
    queryKey: ['petsByStatus', status],
    queryFn: async () => {
      if (!actor) return [];
      return actor.filterPetsByStatus(status);
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetUserListings(user: Principal | null) {
  const { actor, isFetching } = useActor();

  return useQuery<PetProfile[]>({
    queryKey: ['userListings', user?.toString()],
    queryFn: async () => {
      if (!actor || !user) return [];
      return actor.getUserListings(user);
    },
    enabled: !!actor && !isFetching && !!user,
  });
}

// Pet Mutations - Require authentication
export function useAddPet() {
  const { actor } = useActor();
  const { identity } = useInternetIdentity();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (pet: PetProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addPet(pet);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      // Invalidate with the specific user's principal
      if (identity) {
        queryClient.invalidateQueries({ queryKey: ['userListings', identity.getPrincipal().toString()] });
      }
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

export function useUpdatePet() {
  const { actor } = useActor();
  const { identity } = useInternetIdentity();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ petId, updatedPet }: { petId: PetId; updatedPet: PetProfile }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updatePet(petId, updatedPet);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['pet', variables.petId] });
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      // Invalidate with the specific user's principal
      if (identity) {
        queryClient.invalidateQueries({ queryKey: ['userListings', identity.getPrincipal().toString()] });
      }
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

export function useRemovePet() {
  const { actor } = useActor();
  const { identity } = useInternetIdentity();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (petId: PetId) => {
      if (!actor) throw new Error('Actor not available');
      return actor.removePet(petId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      // Invalidate with the specific user's principal
      if (identity) {
        queryClient.invalidateQueries({ queryKey: ['userListings', identity.getPrincipal().toString()] });
      }
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

export function useDeleteListing() {
  const { actor } = useActor();
  const { identity } = useInternetIdentity();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (petId: PetId) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deleteListing(petId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      // Invalidate with the specific user's principal
      if (identity) {
        queryClient.invalidateQueries({ queryKey: ['userListings', identity.getPrincipal().toString()] });
      }
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

export function useMarkPetAdopted() {
  const { actor } = useActor();
  const { identity } = useInternetIdentity();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (petId: PetId) => {
      if (!actor) throw new Error('Actor not available');
      return actor.markPetAdopted(petId);
    },
    onSuccess: (_, petId) => {
      queryClient.invalidateQueries({ queryKey: ['pet', petId] });
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      // Invalidate with the specific user's principal
      if (identity) {
        queryClient.invalidateQueries({ queryKey: ['userListings', identity.getPrincipal().toString()] });
      }
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

// Admin Moderation Mutations
export function useAdminUpdatePet() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ petId, updatedPet }: { petId: PetId; updatedPet: PetProfile }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminUpdatePet(petId, updatedPet);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['pet', variables.petId] });
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      queryClient.invalidateQueries({ queryKey: ['userListings'] });
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

export function useAdminRemovePet() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (petId: PetId) => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminRemovePet(petId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['publicPets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      queryClient.invalidateQueries({ queryKey: ['userListings'] });
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

// Application Queries - Require authentication
export function useGetMyApplications() {
  const { actor, isFetching } = useActor();

  return useQuery<AdoptionApplication[]>({
    queryKey: ['myApplications'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getMyApplications();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetAllApplications() {
  const { actor, isFetching } = useActor();

  return useQuery<AdoptionApplication[]>({
    queryKey: ['allApplications'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllApplications();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSubmitApplication() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (application: AdoptionApplication) => {
      if (!actor) throw new Error('Actor not available');
      return actor.submitApplication(application);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myApplications'] });
      queryClient.invalidateQueries({ queryKey: ['availablePets'] });
      queryClient.invalidateQueries({ queryKey: ['petsByStatus'] });
      queryClient.invalidateQueries({ queryKey: ['inbox'] });
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

export function useUpdateApplicationStatus() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ applicationId, status }: { applicationId: ApplicationId; status: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateApplicationStatus(applicationId, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allApplications'] });
      queryClient.invalidateQueries({ queryKey: ['myApplications'] });
    },
  });
}

// Inquiry Queries - Require authentication
export function useGetMyInquiries() {
  const { actor, isFetching } = useActor();

  return useQuery<InquiryMessage[]>({
    queryKey: ['myInquiries'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getMyInquiries();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetAllInquiries() {
  const { actor, isFetching } = useActor();

  return useQuery<InquiryMessage[]>({
    queryKey: ['allInquiries'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllInquiries();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSubmitInquiry() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (inquiry: InquiryMessage) => {
      if (!actor) throw new Error('Actor not available');
      return actor.submitInquiry(inquiry);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myInquiries'] });
      queryClient.invalidateQueries({ queryKey: ['inbox'] });
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
    },
  });
}

// Messaging Queries - Require authentication
export function useGetInbox() {
  const { actor, isFetching } = useActor();

  return useQuery<MessageThread[]>({
    queryKey: ['inbox'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getInbox();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetMessagesWithUser(otherUser: Principal | null) {
  const { actor, isFetching } = useActor();

  return useQuery<ChatMessage[]>({
    queryKey: ['messages', otherUser?.toString()],
    queryFn: async () => {
      if (!actor || !otherUser) return [];
      return actor.getAllMessagesWithUser(otherUser);
    },
    enabled: !!actor && !isFetching && !!otherUser,
    refetchInterval: 3000,
  });
}

export function useSendMessage() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ receiver, content }: { receiver: Principal; content: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.sendMessage(receiver, content);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['messages', variables.receiver.toString()] });
      queryClient.invalidateQueries({ queryKey: ['inbox'] });
      queryClient.invalidateQueries({ queryKey: ['adminDashboardStats'] });
      queryClient.invalidateQueries({ queryKey: ['userDisplayName'] });
    },
  });
}

export function useMarkMessagesAsRead() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (sender: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.markMessagesAsRead(sender);
    },
    onSuccess: (_, sender) => {
      queryClient.invalidateQueries({ queryKey: ['messages', sender.toString()] });
      queryClient.invalidateQueries({ queryKey: ['inbox'] });
    },
  });
}

// Admin Dashboard Stats - Admin only
export function useGetAdminDashboardStats() {
  const { actor, isFetching } = useActor();

  return useQuery<AdminDashboardStats>({
    queryKey: ['adminDashboardStats'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getAdminDashboardStats();
    },
    enabled: !!actor && !isFetching,
  });
}
