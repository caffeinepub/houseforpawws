import { useState } from 'react';
import { useGetPublicPets, useIsCallerAdmin, useAdminUpdatePet, useAdminRemovePet } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { PawPrint, Edit, Trash2, EyeOff, Eye, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { PetStatus } from '../backend';
import PhotoUpload from '../components/PhotoUpload';
import type { PetProfile } from '../backend';

export default function AdminModerationPage() {
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();
  const { data: allPets = [], isLoading: petsLoading } = useGetPublicPets();
  const adminUpdatePet = useAdminUpdatePet();
  const adminRemovePet = useAdminRemovePet();

  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedPet, setSelectedPet] = useState<PetProfile | null>(null);
  const [editedPet, setEditedPet] = useState<Partial<PetProfile>>({});

  const handleEditClick = (pet: PetProfile) => {
    setSelectedPet(pet);
    setEditedPet({
      name: pet.name,
      petType: pet.petType,
      age: pet.age,
      breed: pet.breed,
      size: pet.size,
      location: pet.location,
      description: pet.description,
      medicalHistory: pet.medicalHistory,
      photos: pet.photos,
      status: pet.status,
      isHidden: pet.isHidden,
    });
    setShowEditDialog(true);
  };

  const handleDeleteClick = (pet: PetProfile) => {
    setSelectedPet(pet);
    setShowDeleteDialog(true);
  };

  const handleUpdatePet = async () => {
    if (!selectedPet || !editedPet.name || !editedPet.petType || !editedPet.breed || !editedPet.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    const updatedPet: PetProfile = {
      ...selectedPet,
      name: editedPet.name,
      petType: editedPet.petType,
      age: editedPet.age || BigInt(0),
      breed: editedPet.breed,
      size: editedPet.size || 'Medium',
      location: editedPet.location,
      description: editedPet.description || '',
      medicalHistory: editedPet.medicalHistory || '',
      photos: editedPet.photos || [],
      status: editedPet.status || selectedPet.status,
      isHidden: editedPet.isHidden ?? selectedPet.isHidden,
    };

    try {
      await adminUpdatePet.mutateAsync({ petId: selectedPet.id, updatedPet });
      toast.success('Pet listing moderated successfully!');
      setShowEditDialog(false);
      setSelectedPet(null);
    } catch (error: any) {
      toast.error('Failed to moderate pet listing');
      console.error(error);
    }
  };

  const handleDeletePet = async () => {
    if (!selectedPet) return;

    try {
      await adminRemovePet.mutateAsync(selectedPet.id);
      toast.success('Pet listing removed successfully!');
      setShowDeleteDialog(false);
      setSelectedPet(null);
    } catch (error: any) {
      toast.error('Failed to remove pet listing');
      console.error(error);
    }
  };

  const handleToggleVisibility = async (pet: PetProfile) => {
    const updatedPet: PetProfile = {
      ...pet,
      isHidden: !pet.isHidden,
    };

    try {
      await adminUpdatePet.mutateAsync({ petId: pet.id, updatedPet });
      toast.success(pet.isHidden ? 'Pet listing is now visible' : 'Pet listing is now hidden');
    } catch (error: any) {
      toast.error('Failed to update visibility');
      console.error(error);
    }
  };

  const statusColors = {
    available: 'bg-green-500/10 text-green-700 dark:text-green-400',
    pending: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400',
    adopted: 'bg-blue-500/10 text-blue-700 dark:text-blue-400',
  };

  if (adminLoading || petsLoading) {
    return (
      <div className="container py-8">
        <Skeleton className="mb-6 h-10 w-64" />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-48 w-full rounded-lg" />
              </CardHeader>
              <CardContent>
                <Skeleton className="mb-2 h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertDescription>
            Access denied. This page is only accessible to administrators.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-chart-1 to-primary bg-clip-text text-transparent">
            Admin Moderation
          </h1>
        </div>
        <p className="text-muted-foreground">
          Moderate all pet listings - edit, hide, or remove any listing on the platform
        </p>
      </div>

      <Alert className="mb-6 border-primary/20 bg-gradient-to-br from-primary/5 to-chart-1/5">
        <Shield className="h-4 w-4 text-primary" />
        <AlertDescription>
          <strong>Admin Mode:</strong> You have full moderation capabilities. Changes made here affect all users.
        </AlertDescription>
      </Alert>

      {allPets.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <PawPrint className="mb-4 h-16 w-16 text-muted-foreground/50" />
            <h3 className="mb-2 text-xl font-semibold">No pet listings</h3>
            <p className="text-muted-foreground">
              There are no pet listings to moderate at this time.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="mb-6 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Total listings: <span className="font-semibold text-foreground">{allPets.length}</span>
              {' • '}
              Hidden: <span className="font-semibold text-foreground">{allPets.filter(p => p.isHidden).length}</span>
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {allPets.map((pet) => (
              <Card key={pet.id} className={`group overflow-hidden transition-all hover:shadow-lg ${pet.isHidden ? 'opacity-60 border-dashed' : ''}`}>
                <CardHeader className="p-0">
                  <div className="relative aspect-square overflow-hidden bg-muted">
                    {pet.photos.length > 0 ? (
                      <img
                        src={pet.photos[0].getDirectURL()}
                        alt={pet.name}
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <PawPrint className="h-16 w-16 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute right-2 top-2 flex gap-2">
                      <Badge className={statusColors[pet.status]}>{pet.status}</Badge>
                      {pet.isHidden && (
                        <Badge variant="destructive" className="gap-1">
                          <EyeOff className="h-3 w-3" />
                          Hidden
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <CardTitle className="mb-2 line-clamp-1">{pet.name}</CardTitle>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p>
                      <span className="font-medium">Breed:</span> {pet.breed}
                    </p>
                    <p>
                      <span className="font-medium">Age:</span> {Number(pet.age)} years
                    </p>
                    <p>
                      <span className="font-medium">Location:</span> {pet.location}
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col gap-2 p-4 pt-0">
                  <div className="flex w-full gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleToggleVisibility(pet)}
                      className="flex-1 gap-2"
                      disabled={adminUpdatePet.isPending}
                    >
                      {pet.isHidden ? (
                        <>
                          <Eye className="h-4 w-4" />
                          Show
                        </>
                      ) : (
                        <>
                          <EyeOff className="h-4 w-4" />
                          Hide
                        </>
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditClick(pet)}
                      className="flex-1 gap-2"
                    >
                      <Edit className="h-4 w-4" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteClick(pet)}
                      className="flex-1 gap-2"
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </>
      )}

      {/* Edit Pet Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Admin: Moderate Pet Listing
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <PhotoUpload
              photos={editedPet.photos || []}
              onChange={(photos) => setEditedPet({ ...editedPet, photos })}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-name"
                  value={editedPet.name}
                  onChange={(e) => setEditedPet({ ...editedPet, name: e.target.value })}
                  placeholder="Pet name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-petType">
                  Type <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-petType"
                  value={editedPet.petType}
                  onChange={(e) => setEditedPet({ ...editedPet, petType: e.target.value })}
                  placeholder="Dog, Cat, etc."
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-breed">
                  Breed <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-breed"
                  value={editedPet.breed}
                  onChange={(e) => setEditedPet({ ...editedPet, breed: e.target.value })}
                  placeholder="Breed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-age">Age (years)</Label>
                <Input
                  id="edit-age"
                  type="number"
                  value={Number(editedPet.age)}
                  onChange={(e) => setEditedPet({ ...editedPet, age: BigInt(e.target.value || 0) })}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-size">Size</Label>
                <Select value={editedPet.size} onValueChange={(value) => setEditedPet({ ...editedPet, size: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-location">
                  Location <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-location"
                  value={editedPet.location}
                  onChange={(e) => setEditedPet({ ...editedPet, location: e.target.value })}
                  placeholder="City, State"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-status">Adoption Status</Label>
                <Select 
                  value={editedPet.status} 
                  onValueChange={(value) => setEditedPet({ ...editedPet, status: value as PetStatus })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PetStatus.available}>Available</SelectItem>
                    <SelectItem value={PetStatus.pending}>Pending</SelectItem>
                    <SelectItem value={PetStatus.adopted}>Adopted</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-visibility">Visibility</Label>
                <Select 
                  value={editedPet.isHidden ? 'hidden' : 'visible'} 
                  onValueChange={(value) => setEditedPet({ ...editedPet, isHidden: value === 'hidden' })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select visibility" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="visible">Visible to Public</SelectItem>
                    <SelectItem value="hidden">Hidden from Public</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editedPet.description}
                onChange={(e) => setEditedPet({ ...editedPet, description: e.target.value })}
                placeholder="Describe the pet's personality, behavior, etc."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-medicalHistory">Medical History</Label>
              <Textarea
                id="edit-medicalHistory"
                value={editedPet.medicalHistory}
                onChange={(e) => setEditedPet({ ...editedPet, medicalHistory: e.target.value })}
                placeholder="Vaccinations, health conditions, etc."
                rows={3}
              />
            </div>
            <Button onClick={handleUpdatePet} disabled={adminUpdatePet.isPending} className="w-full">
              {adminUpdatePet.isPending ? 'Updating...' : 'Update Pet Listing'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the listing for <strong>{selectedPet?.name}</strong>. This action cannot be undone and will affect the user who created this listing.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeletePet}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete Permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
