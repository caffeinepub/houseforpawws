import { useGetMyApplications, useGetMyInquiries } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, MessageCircle, Calendar } from 'lucide-react';
import type { View } from '../App';

interface MyApplicationsPageProps {
  onNavigate: (view: View) => void;
}

export default function MyApplicationsPage({ onNavigate }: MyApplicationsPageProps) {
  const { data: applications = [], isLoading: applicationsLoading } = useGetMyApplications();
  const { data: inquiries = [], isLoading: inquiriesLoading } = useGetMyInquiries();

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400',
    approved: 'bg-green-500/10 text-green-700 dark:text-green-400',
    rejected: 'bg-red-500/10 text-red-700 dark:text-red-400',
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold">My Applications & Inquiries</h1>
        <p className="text-muted-foreground">Track your adoption applications and inquiries</p>
      </div>

      <Tabs defaultValue="applications" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="applications" className="gap-2">
            <FileText className="h-4 w-4" />
            Applications ({applications.length})
          </TabsTrigger>
          <TabsTrigger value="inquiries" className="gap-2">
            <MessageCircle className="h-4 w-4" />
            Inquiries ({inquiries.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="applications" className="mt-6 space-y-4">
          {applicationsLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-1/3" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))
          ) : applications.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <FileText className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <h3 className="mb-2 text-lg font-semibold">No applications yet</h3>
                <p className="text-sm text-muted-foreground">
                  Browse available pets and submit an application to get started
                </p>
              </CardContent>
            </Card>
          ) : (
            applications.map((app) => (
              <Card key={app.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle>Application for Pet ID: {app.petId}</CardTitle>
                    <Badge className={statusColors[app.status] || statusColors.pending}>{app.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="mb-1 text-sm font-medium">Your Message:</p>
                    <p className="text-sm text-muted-foreground">{app.message}</p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    Submitted: {new Date(Number(app.submittedAt) / 1000000).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="inquiries" className="mt-6 space-y-4">
          {inquiriesLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-1/3" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))
          ) : inquiries.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <MessageCircle className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <h3 className="mb-2 text-lg font-semibold">No inquiries yet</h3>
                <p className="text-sm text-muted-foreground">
                  Send an inquiry about a pet to ask questions before applying
                </p>
              </CardContent>
            </Card>
          ) : (
            inquiries.map((inquiry) => (
              <Card key={inquiry.id}>
                <CardHeader>
                  <CardTitle>Inquiry about Pet ID: {inquiry.petId}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="mb-1 text-sm font-medium">Your Message:</p>
                    <p className="text-sm text-muted-foreground">{inquiry.message}</p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    Sent: {new Date(Number(inquiry.createdAt) / 1000000).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
