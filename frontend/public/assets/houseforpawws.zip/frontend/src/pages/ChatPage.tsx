import { useState, useEffect, useRef } from 'react';
import { useGetMessagesWithUser, useSendMessage, useMarkMessagesAsRead, useGetCallerUserProfile, useGetUserDisplayName, useCanUsePlatformFeatures } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ArrowLeft, Send, Loader2, Check, CheckCheck } from 'lucide-react';
import { toast } from 'sonner';
import type { Principal } from '@icp-sdk/core/principal';
import { useInternetIdentity } from '../hooks/useInternetIdentity';

interface ChatPageProps {
  otherUser: Principal;
  onBack: () => void;
}

export default function ChatPage({ otherUser, onBack }: ChatPageProps) {
  const { identity } = useInternetIdentity();
  const { data: messages, isLoading } = useGetMessagesWithUser(otherUser);
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: otherUserDisplayName } = useGetUserDisplayName(otherUser);
  const { data: canUsePlatformFeatures } = useCanUsePlatformFeatures();
  const sendMessageMutation = useSendMessage();
  const markAsReadMutation = useMarkMessagesAsRead();
  const [messageText, setMessageText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const hasMarkedAsRead = useRef(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Mark messages as read when viewing the chat
  useEffect(() => {
    if (messages && messages.length > 0 && !hasMarkedAsRead.current && identity) {
      const unreadMessages = messages.filter(
        (msg) => msg.sender.toString() === otherUser.toString() && !msg.status.read
      );
      
      if (unreadMessages.length > 0) {
        markAsReadMutation.mutate(otherUser);
        hasMarkedAsRead.current = true;
      }
    }
  }, [messages, otherUser, identity, markAsReadMutation]);

  const handleSendMessage = async () => {
    if (!messageText.trim() || !identity) return;

    try {
      await sendMessageMutation.mutateAsync({
        receiver: otherUser,
        content: messageText.trim(),
      });
      setMessageText('');
    } catch (error: any) {
      toast.error(error.message || 'Failed to send message');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTimestamp = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getInitials = (name: string) => {
    if (!name || name === '' || name === 'User') return 'U';
    const words = name.trim().split(' ');
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  const renderReadReceipt = (message: any, isMyMessage: boolean) => {
    if (!isMyMessage) return null;

    if (message.status.read) {
      return (
        <span title="Read">
          <CheckCheck className="inline h-3 w-3 text-[oklch(var(--chart-2))]" />
        </span>
      );
    } else if (message.status.sent) {
      return (
        <span title="Sent">
          <Check className="inline h-3 w-3 text-muted-foreground" />
        </span>
      );
    }
    return null;
  };

  if (!identity || !userProfile) {
    return (
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Chat</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please log in to view messages</p>
            <Button onClick={onBack} variant="outline" className="mt-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!canUsePlatformFeatures || !userProfile.displayName) {
    return (
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Chat</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              You must accept the Terms of Service and set a display name to send messages
            </p>
            <Button onClick={onBack} variant="outline" className="mt-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Use the display name from the backend query
  const receiverDisplayName = otherUserDisplayName || 'User';

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <Card className="flex h-[calc(100vh-12rem)] flex-col">
        <CardHeader className="border-b">
          <div className="flex items-center gap-4">
            <Button onClick={onBack} variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Avatar className="h-10 w-10">
              <AvatarFallback className="bg-primary/10 text-primary">
                {getInitials(receiverDisplayName)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-lg">{receiverDisplayName}</CardTitle>
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex-1 overflow-y-auto p-4">
          {isLoading ? (
            <div className="flex h-full items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : messages && messages.length > 0 ? (
            <div className="space-y-4">
              {messages.map((message) => {
                const isMyMessage = message.sender.toString() === identity.getPrincipal().toString();
                
                // Use display names directly from the message data (publicly visible)
                // These are populated by the backend when messages are created
                const displayName = isMyMessage
                  ? (userProfile.displayName || 'You')
                  : (message.senderDisplayName && message.senderDisplayName !== '' 
                      ? message.senderDisplayName 
                      : receiverDisplayName);

                return (
                  <div key={message.id.toString()} className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex max-w-[70%] gap-2 ${isMyMessage ? 'flex-row-reverse' : 'flex-row'}`}>
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {getInitials(displayName)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className={`mb-1 text-xs font-medium ${isMyMessage ? 'text-right' : 'text-left'}`}>
                          {displayName}
                        </p>
                        <div
                          className={`rounded-lg px-4 py-2 ${
                            isMyMessage
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted text-muted-foreground'
                          }`}
                        >
                          <p className="break-words text-sm">{message.content}</p>
                        </div>
                        <p className={`mt-1 text-xs text-muted-foreground flex items-center gap-1 ${isMyMessage ? 'justify-end' : 'justify-start'}`}>
                          {formatTimestamp(message.timestamp)}
                          {renderReadReceipt(message, isMyMessage)}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          ) : (
            <div className="flex h-full items-center justify-center">
              <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
            </div>
          )}
        </CardContent>

        <div className="border-t p-4">
          <div className="flex gap-2">
            <Input
              placeholder={`Message ${receiverDisplayName}...`}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={sendMessageMutation.isPending}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!messageText.trim() || sendMessageMutation.isPending}
              size="icon"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
