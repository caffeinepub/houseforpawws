import { useState } from 'react';
import {
  useGetAllApplications,
  useGetAllInquiries,
  useFilterPetsByStatus,
  useAddPet,
  useUpdatePet,
  useRemovePet,
  useMarkPetAdopted,
  useUpdateApplicationStatus,
  useCanUsePlatformFeatures,
} from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PlusCircle, FileText, MessageCircle, PawPrint, Trash2, Check } from 'lucide-react';
import { toast } from 'sonner';
import { PetStatus } from '../backend';
import TOSModal from '../components/TOSModal';
import PhotoUpload from '../components/PhotoUpload';
import type { View } from '../App';
import type { PetProfile } from '../backend';

interface AdminDashboardProps {
  onNavigate: (view: View) => void;
}

export default function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const { data: applications = [] } = useGetAllApplications();
  const { data: inquiries = [] } = useGetAllInquiries();
  const { data: allPets = [] } = useFilterPetsByStatus(PetStatus.available);
  const { data: pendingPets = [] } = useFilterPetsByStatus(PetStatus.pending);
  const { data: adoptedPets = [] } = useFilterPetsByStatus(PetStatus.adopted);
  const { data: canUseFeatures = false, isLoading: featuresLoading } = useCanUsePlatformFeatures();

  const addPet = useAddPet();
  const updatePet = useUpdatePet();
  const removePet = useRemovePet();
  const markAdopted = useMarkPetAdopted();
  const updateApplicationStatus = useUpdateApplicationStatus();

  const [showAddPetDialog, setShowAddPetDialog] = useState(false);
  const [showTOSModal, setShowTOSModal] = useState(false);
  const [newPet, setNewPet] = useState<Partial<PetProfile>>({
    name: '',
    petType: '',
    age: BigInt(0),
    breed: '',
    size: '',
    location: '',
    description: '',
    medicalHistory: '',
    photos: [],
  });

  const handleAddPetClick = () => {
    if (!canUseFeatures) {
      setShowTOSModal(true);
    } else {
      setShowAddPetDialog(true);
    }
  };

  const handleTOSAccepted = () => {
    setShowTOSModal(false);
    setShowAddPetDialog(true);
  };

  const handleAddPet = async () => {
    if (!newPet.name || !newPet.petType || !newPet.breed || !newPet.location) {
      toast.error('Please fill in all required fields including location');
      return;
    }

    const pet: PetProfile = {
      id: `pet-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: newPet.name,
      petType: newPet.petType,
      age: newPet.age || BigInt(0),
      breed: newPet.breed,
      size: newPet.size || 'Medium',
      location: newPet.location,
      description: newPet.description || '',
      medicalHistory: newPet.medicalHistory || '',
      photos: newPet.photos || [],
      status: PetStatus.available,
      createdAt: BigInt(Date.now() * 1000000),
      isHidden: false,
    };

    try {
      await addPet.mutateAsync(pet);
      toast.success('Pet added successfully!');
      setShowAddPetDialog(false);
      setNewPet({
        name: '',
        petType: '',
        age: BigInt(0),
        breed: '',
        size: '',
        location: '',
        description: '',
        medicalHistory: '',
        photos: [],
      });
    } catch (error: any) {
      if (error?.message?.includes('Terms of Service') || error?.message?.includes('display name')) {
        toast.error('You must accept the Terms of Service and set a display name before uploading pets');
        setShowAddPetDialog(false);
        setShowTOSModal(true);
      } else {
        toast.error('Failed to add pet');
        console.error(error);
      }
    }
  };

  const handleRemovePet = async (petId: string) => {
    if (!confirm('Are you sure you want to remove this pet?')) return;

    try {
      await removePet.mutateAsync(petId);
      toast.success('Pet removed successfully');
    } catch (error) {
      toast.error('Failed to remove pet');
      console.error(error);
    }
  };

  const handleMarkAdopted = async (petId: string) => {
    try {
      await markAdopted.mutateAsync(petId);
      toast.success('Pet marked as adopted!');
    } catch (error) {
      toast.error('Failed to mark pet as adopted');
      console.error(error);
    }
  };

  const handleUpdateApplicationStatus = async (applicationId: string, status: string) => {
    try {
      await updateApplicationStatus.mutateAsync({ applicationId, status });
      toast.success('Application status updated');
    } catch (error) {
      toast.error('Failed to update application status');
      console.error(error);
    }
  };

  const allPetsCount = allPets.length + pendingPets.length + adoptedPets.length;

  return (
    <div className="container py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="mb-2 text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage pets, applications, and inquiries</p>
        </div>
        <Button className="gap-2" onClick={handleAddPetClick} disabled={featuresLoading}>
          <PlusCircle className="h-4 w-4" />
          Add New Pet
        </Button>
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pets</CardTitle>
            <PawPrint className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{allPetsCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available</CardTitle>
            <PawPrint className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{allPets.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Applications</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{applications.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inquiries</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inquiries.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pets" className="w-full">
        <TabsList className="grid w-full max-w-2xl grid-cols-3">
          <TabsTrigger value="pets">Pets</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="inquiries">Inquiries</TabsTrigger>
        </TabsList>

        <TabsContent value="pets" className="mt-6 space-y-4">
          {allPetsCount === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <PawPrint className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <h3 className="mb-2 text-lg font-semibold">No pets yet</h3>
                <p className="text-sm text-muted-foreground">Add your first pet to get started</p>
              </CardContent>
            </Card>
          ) : (
            [...allPets, ...pendingPets, ...adoptedPets].map((pet) => (
              <Card key={pet.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{pet.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {pet.breed} • {Number(pet.age)} years • {pet.size} • {pet.location}
                      </p>
                    </div>
                    <Badge
                      className={
                        pet.status === 'available'
                          ? 'bg-green-500/10 text-green-700'
                          : pet.status === 'pending'
                            ? 'bg-yellow-500/10 text-yellow-700'
                            : 'bg-blue-500/10 text-blue-700'
                      }
                    >
                      {pet.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    {pet.status === 'pending' && (
                      <Button size="sm" onClick={() => handleMarkAdopted(pet.id)} className="gap-2">
                        <Check className="h-4 w-4" />
                        Mark Adopted
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleRemovePet(pet.id)}
                      className="gap-2"
                    >
                      <Trash2 className="h-4 w-4" />
                      Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="applications" className="mt-6 space-y-4">
          {applications.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <FileText className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <h3 className="mb-2 text-lg font-semibold">No applications yet</h3>
              </CardContent>
            </Card>
          ) : (
            applications.map((app) => (
              <Card key={app.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>Application for Pet: {app.petId}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        From: {app.adopter.name} ({app.adopter.email})
                      </p>
                    </div>
                    <Badge>{app.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="mb-1 text-sm font-medium">Message:</p>
                    <p className="text-sm text-muted-foreground">{app.message}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleUpdateApplicationStatus(app.id, 'approved')}
                      disabled={app.status === 'approved'}
                    >
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleUpdateApplicationStatus(app.id, 'rejected')}
                      disabled={app.status === 'rejected'}
                    >
                      Reject
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="inquiries" className="mt-6 space-y-4">
          {inquiries.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <MessageCircle className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <h3 className="mb-2 text-lg font-semibold">No inquiries yet</h3>
              </CardContent>
            </Card>
          ) : (
            inquiries.map((inquiry) => (
              <Card key={inquiry.id}>
                <CardHeader>
                  <CardTitle>Inquiry about Pet: {inquiry.petId}</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    From: {inquiry.senderName} ({inquiry.senderEmail})
                  </p>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{inquiry.message}</p>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={showAddPetDialog} onOpenChange={setShowAddPetDialog}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Pet</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <PhotoUpload
              photos={newPet.photos || []}
              onChange={(photos) => setNewPet({ ...newPet, photos })}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="name"
                  value={newPet.name}
                  onChange={(e) => setNewPet({ ...newPet, name: e.target.value })}
                  placeholder="Pet name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="petType">
                  Type <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="petType"
                  value={newPet.petType}
                  onChange={(e) => setNewPet({ ...newPet, petType: e.target.value })}
                  placeholder="Dog, Cat, etc."
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="breed">
                  Breed <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="breed"
                  value={newPet.breed}
                  onChange={(e) => setNewPet({ ...newPet, breed: e.target.value })}
                  placeholder="Breed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="age">Age (years)</Label>
                <Input
                  id="age"
                  type="number"
                  value={Number(newPet.age)}
                  onChange={(e) => setNewPet({ ...newPet, age: BigInt(e.target.value || 0) })}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="size">Size</Label>
                <Select value={newPet.size} onValueChange={(value) => setNewPet({ ...newPet, size: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">
                  Location <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="location"
                  value={newPet.location}
                  onChange={(e) => setNewPet({ ...newPet, location: e.target.value })}
                  placeholder="City, State"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newPet.description}
                onChange={(e) => setNewPet({ ...newPet, description: e.target.value })}
                placeholder="Describe the pet's personality, behavior, etc."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="medicalHistory">Medical History</Label>
              <Textarea
                id="medicalHistory"
                value={newPet.medicalHistory}
                onChange={(e) => setNewPet({ ...newPet, medicalHistory: e.target.value })}
                placeholder="Vaccinations, health conditions, etc."
                rows={3}
              />
            </div>
            <Button onClick={handleAddPet} disabled={addPet.isPending} className="w-full">
              {addPet.isPending ? 'Adding...' : 'Add Pet'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <TOSModal
        open={showTOSModal}
        onClose={() => setShowTOSModal(false)}
        onAccepted={handleTOSAccepted}
      />
    </div>
  );
}
