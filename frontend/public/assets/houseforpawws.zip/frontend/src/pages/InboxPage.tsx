import { useGetInbox, useGetCallerUserProfile, useGetUserDisplayName, useCanUsePlatformFeatures } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageCircle, ArrowLeft, Loader2, Check, CheckCheck } from 'lucide-react';
import type { View } from '../App';
import type { Principal } from '@icp-sdk/core/principal';
import { useInternetIdentity } from '../hooks/useInternetIdentity';

interface InboxPageProps {
  onNavigate: (view: View, petId?: string, chatUser?: Principal) => void;
}

function ThreadItem({
  otherUser,
  lastMessage,
  currentUserPrincipal,
  onClick,
}: {
  otherUser: Principal;
  lastMessage: any;
  currentUserPrincipal: string;
  onClick: () => void;
}) {
  const { data: otherUserDisplayName } = useGetUserDisplayName(otherUser);

  const formatTimestamp = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const getInitials = (name: string) => {
    if (!name || name === '' || name === 'User') return 'U';
    const words = name.trim().split(' ');
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  const truncateMessage = (content: string, maxLength: number = 60) => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  const renderReadReceipt = (message: any, isMyMessage: boolean) => {
    if (!isMyMessage) return null;

    if (message.status.read) {
      return (
        <span title="Read">
          <CheckCheck className="inline h-3 w-3 ml-1 text-[oklch(var(--chart-2))]" />
        </span>
      );
    } else if (message.status.sent) {
      return (
        <span title="Sent">
          <Check className="inline h-3 w-3 ml-1 text-muted-foreground" />
        </span>
      );
    }
    return null;
  };

  // Get display name from message data (publicly visible) or fallback to backend query
  const getDisplayNameFromMessage = () => {
    if (!lastMessage) return otherUserDisplayName || 'User';
    
    const isMyMessage = lastMessage.sender.toString() === currentUserPrincipal;
    
    if (isMyMessage) {
      // If I sent the message, use the receiverDisplayName from the message
      if (lastMessage.receiverDisplayName && lastMessage.receiverDisplayName !== '') {
        return lastMessage.receiverDisplayName;
      }
    } else {
      // If I received the message, use the senderDisplayName from the message
      if (lastMessage.senderDisplayName && lastMessage.senderDisplayName !== '') {
        return lastMessage.senderDisplayName;
      }
    }
    
    // Fallback to backend query
    return otherUserDisplayName || 'User';
  };

  const displayName = getDisplayNameFromMessage();
  const isMyMessage = lastMessage?.sender.toString() === currentUserPrincipal;
  const senderDisplayName = isMyMessage ? 'You' : displayName;

  return (
    <Card
      className="cursor-pointer transition-all hover:border-primary hover:shadow-md"
      onClick={onClick}
    >
      <CardContent className="flex items-center gap-4 p-4">
        <Avatar className="h-12 w-12">
          <AvatarFallback className="bg-primary/10 text-primary">
            {getInitials(displayName)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 overflow-hidden">
          <div className="flex items-center justify-between">
            <p className="font-semibold">{displayName}</p>
            {lastMessage && (
              <span className="text-xs text-muted-foreground">
                {formatTimestamp(lastMessage.timestamp)}
              </span>
            )}
          </div>
          {lastMessage && (
            <p className="text-sm text-muted-foreground flex items-center">
              {senderDisplayName}: {truncateMessage(lastMessage.content)}
              {renderReadReceipt(lastMessage, isMyMessage)}
            </p>
          )}
        </div>
        <MessageCircle className="h-5 w-5 text-muted-foreground" />
      </CardContent>
    </Card>
  );
}

export default function InboxPage({ onNavigate }: InboxPageProps) {
  const { identity } = useInternetIdentity();
  const { data: threads, isLoading } = useGetInbox();
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: canUsePlatformFeatures } = useCanUsePlatformFeatures();

  const getOtherUser = (participants: Principal[]) => {
    if (!identity) return null;
    const myPrincipal = identity.getPrincipal().toString();
    return participants.find((p) => p.toString() !== myPrincipal) || null;
  };

  if (!identity || !userProfile) {
    return (
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Messages</CardTitle>
            <CardDescription>Please log in to view your messages</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (!canUsePlatformFeatures || !userProfile.displayName) {
    return (
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Messages</CardTitle>
            <CardDescription>
              You must accept the Terms of Service and set a display name to access messages
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => onNavigate('home')} variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Messages</h1>
          <p className="text-muted-foreground">Your conversations with other users</p>
        </div>
        <Button onClick={() => onNavigate('home')} variant="outline">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </CardContent>
        </Card>
      ) : threads && threads.length > 0 ? (
        <div className="space-y-3">
          {threads.map((thread, index) => {
            const otherUser = getOtherUser(thread.participants);
            if (!otherUser) return null;

            return (
              <ThreadItem
                key={index}
                otherUser={otherUser}
                lastMessage={thread.lastMessage}
                currentUserPrincipal={identity.getPrincipal().toString()}
                onClick={() => onNavigate('chat', undefined, otherUser)}
              />
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageCircle className="mb-4 h-16 w-16 text-muted-foreground" />
            <h3 className="mb-2 text-xl font-semibold">No messages yet</h3>
            <p className="text-center text-muted-foreground">
              Start a conversation by contacting other users about pets
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
