import { useState, useEffect } from 'react';
import { useGetPet, useSubmitApplication, useSubmitInquiry, useGetCallerUserProfile, useIsPetOwner, useUpdatePet, useCanUsePlatformFeatures } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, PawPrint, Calendar, Ruler, Heart, MessageCircle, LogIn, MapPin, Edit, CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import TOSModal from '../components/TOSModal';
import BreederWarningModal from '../components/BreederWarningModal';
import PhotoUpload from '../components/PhotoUpload';
import { PetStatus } from '../backend';
import type { PetId, AdoptionApplication, InquiryMessage, PetProfile } from '../backend';
import type { View } from '../App';
import type { Principal } from '@icp-sdk/core/principal';

interface PetDetailPageProps {
  petId: PetId;
  onBack: () => void;
  onNavigate?: (view: View, petId?: string, chatUser?: Principal) => void;
}

export default function PetDetailPage({ petId, onBack, onNavigate }: PetDetailPageProps) {
  const { data: pet, isLoading } = useGetPet(petId);
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: isPetOwner = false } = useIsPetOwner(petId);
  const { data: canUsePlatformFeatures } = useCanUsePlatformFeatures();
  const { identity, login } = useInternetIdentity();
  const submitApplication = useSubmitApplication();
  const submitInquiry = useSubmitInquiry();
  const updatePet = useUpdatePet();

  const [applicationMessage, setApplicationMessage] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [showApplicationDialog, setShowApplicationDialog] = useState(false);
  const [showInquiryDialog, setShowInquiryDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showTOSModal, setShowTOSModal] = useState(false);
  const [showBreederWarning, setShowBreederWarning] = useState(false);
  const [pendingAction, setPendingAction] = useState<'application' | 'inquiry' | null>(null);
  
  const [editedPet, setEditedPet] = useState<Partial<PetProfile>>({});

  const isAuthenticated = !!identity;
  const hasAcceptedTOS = canUsePlatformFeatures && userProfile?.displayName;

  // Show breeder warning when page loads
  useEffect(() => {
    setShowBreederWarning(true);
  }, [petId]);

  const handleEditClick = () => {
    if (pet) {
      setEditedPet({
        name: pet.name,
        petType: pet.petType,
        age: pet.age,
        breed: pet.breed,
        size: pet.size,
        location: pet.location,
        description: pet.description,
        medicalHistory: pet.medicalHistory,
        photos: pet.photos,
        status: pet.status,
      });
      setShowEditDialog(true);
    }
  };

  const handleUpdatePet = async () => {
    if (!pet || !editedPet.name || !editedPet.petType || !editedPet.breed || !editedPet.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    const updatedPet: PetProfile = {
      ...pet,
      name: editedPet.name,
      petType: editedPet.petType,
      age: editedPet.age || BigInt(0),
      breed: editedPet.breed,
      size: editedPet.size || 'Medium',
      location: editedPet.location,
      description: editedPet.description || '',
      medicalHistory: editedPet.medicalHistory || '',
      photos: editedPet.photos || [],
      status: editedPet.status || pet.status,
    };

    try {
      await updatePet.mutateAsync({ petId: pet.id, updatedPet });
      toast.success('Pet listing updated successfully!');
      setShowEditDialog(false);
    } catch (error: any) {
      if (error?.message?.includes('Unauthorized')) {
        toast.error('You can only edit your own pet listings.');
      } else if (error?.message?.includes('Terms of Service') || error?.message?.includes('display name')) {
        toast.error('You must accept the Terms of Service and set a display name to edit pets.');
      } else {
        toast.error('Failed to update pet listing');
        console.error(error);
      }
    }
  };

  const handleStatusChange = async (newStatus: PetStatus) => {
    if (!pet) return;

    const updatedPet: PetProfile = {
      ...pet,
      status: newStatus,
    };

    try {
      await updatePet.mutateAsync({ petId: pet.id, updatedPet });
      toast.success(`Pet marked as ${newStatus}!`);
    } catch (error: any) {
      toast.error('Failed to update pet status');
      console.error(error);
    }
  };

  const handleApplicationClick = () => {
    if (!isAuthenticated) {
      toast.info('Please log in to apply for adoption');
      return;
    }
    setShowBreederWarning(true);
    if (!hasAcceptedTOS) {
      setPendingAction('application');
      setShowTOSModal(true);
    } else {
      setShowApplicationDialog(true);
    }
  };

  const handleInquiryClick = () => {
    if (!isAuthenticated) {
      toast.info('Please log in to send an inquiry');
      return;
    }
    setShowBreederWarning(true);
    if (!hasAcceptedTOS) {
      setPendingAction('inquiry');
      setShowTOSModal(true);
    } else {
      setShowInquiryDialog(true);
    }
  };

  const handleTOSAccepted = () => {
    setShowTOSModal(false);
    if (pendingAction === 'application') {
      setShowApplicationDialog(true);
    } else if (pendingAction === 'inquiry') {
      setShowInquiryDialog(true);
    }
    setPendingAction(null);
  };

  const handleSubmitApplication = async () => {
    if (!userProfile || !pet || !identity) return;

    const application: AdoptionApplication = {
      id: `app-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      petId: pet.id,
      adopter: {
        displayName: userProfile.displayName,
        name: userProfile.name,
        email: userProfile.email,
        phone: userProfile.phone,
        address: userProfile.address,
        preferences: applicationMessage,
      },
      message: applicationMessage,
      status: 'pending',
      submittedAt: BigInt(Date.now() * 1000000),
      submittedBy: identity.getPrincipal(),
    };

    try {
      await submitApplication.mutateAsync(application);
      toast.success('Application submitted! A message thread has been created with the pet owner.');
      setShowApplicationDialog(false);
      setApplicationMessage('');
      
      if (onNavigate && pet.owner) {
        setTimeout(() => {
          onNavigate('chat', undefined, pet.owner);
        }, 1500);
      }
    } catch (error: any) {
      if (error.message?.includes('Terms of Service') || error.message?.includes('display name')) {
        toast.error('Please accept the Terms of Service and set a display name to submit applications.');
        setShowApplicationDialog(false);
        setShowTOSModal(true);
        setPendingAction('application');
      } else {
        toast.error('Failed to submit application');
        console.error(error);
      }
    }
  };

  const handleSubmitInquiry = async () => {
    if (!userProfile || !pet || !identity) return;

    const inquiry: InquiryMessage = {
      id: `inq-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      petId: pet.id,
      senderDisplayName: userProfile.displayName,
      senderName: userProfile.name,
      senderEmail: userProfile.email,
      message: inquiryMessage,
      createdAt: BigInt(Date.now() * 1000000),
      submittedBy: identity.getPrincipal(),
    };

    try {
      await submitInquiry.mutateAsync(inquiry);
      toast.success('Inquiry sent! A message thread has been created with the pet owner.');
      setShowInquiryDialog(false);
      setInquiryMessage('');
      
      if (onNavigate && pet.owner) {
        setTimeout(() => {
          onNavigate('chat', undefined, pet.owner);
        }, 1500);
      }
    } catch (error: any) {
      if (error.message?.includes('Terms of Service') || error.message?.includes('display name')) {
        toast.error('Please accept the Terms of Service and set a display name to send inquiries.');
        setShowInquiryDialog(false);
        setShowTOSModal(true);
        setPendingAction('inquiry');
      } else {
        toast.error('Failed to send inquiry');
        console.error(error);
      }
    }
  };

  if (isLoading) {
    return (
      <div className="container py-8">
        <Skeleton className="mb-4 h-10 w-32" />
        <div className="grid gap-8 lg:grid-cols-2">
          <Skeleton className="aspect-square w-full rounded-lg" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/2" />
            <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!pet) {
    return (
      <div className="container py-8">
        <Button onClick={onBack} variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <PawPrint className="mb-4 h-16 w-16 text-muted-foreground/50" />
          <h3 className="mb-2 text-xl font-semibold">Pet not found</h3>
        </div>
      </div>
    );
  }

  const statusColors = {
    available: 'bg-green-500/10 text-green-700 dark:text-green-400',
    pending: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400',
    adopted: 'bg-blue-500/10 text-blue-700 dark:text-blue-400',
  };

  return (
    <div className="container py-8">
      <div className="mb-6 flex items-center justify-between">
        <Button onClick={onBack} variant="ghost">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Pets
        </Button>
        {isPetOwner && (
          <div className="flex gap-2">
            <Button onClick={handleEditClick} variant="outline" className="gap-2">
              <Edit className="h-4 w-4" />
              Edit Listing
            </Button>
          </div>
        )}
      </div>

      {/* Owner Control Panel */}
      {isPetOwner && (
        <Card className="mb-6 border-primary/20 bg-gradient-to-br from-primary/5 via-chart-1/5 to-chart-2/5">
          <CardHeader>
            <CardTitle className="text-lg">Listing Control Panel</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-sm font-medium text-muted-foreground">Update Status:</span>
              <Button
                size="sm"
                variant={pet.status === PetStatus.available ? 'default' : 'outline'}
                onClick={() => handleStatusChange(PetStatus.available)}
                disabled={pet.status === PetStatus.available || updatePet.isPending}
                className="gap-2"
              >
                <CheckCircle2 className="h-4 w-4" />
                Available
              </Button>
              <Button
                size="sm"
                variant={pet.status === PetStatus.pending ? 'default' : 'outline'}
                onClick={() => handleStatusChange(PetStatus.pending)}
                disabled={pet.status === PetStatus.pending || updatePet.isPending}
                className="gap-2"
              >
                <Calendar className="h-4 w-4" />
                Pending
              </Button>
              <Button
                size="sm"
                variant={pet.status === PetStatus.adopted ? 'default' : 'outline'}
                onClick={() => handleStatusChange(PetStatus.adopted)}
                disabled={pet.status === PetStatus.adopted || updatePet.isPending}
                className="gap-2"
              >
                <Heart className="h-4 w-4 fill-current" />
                Adopted
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
            {pet.photos.length > 0 ? (
              <img
                src={pet.photos[0].getDirectURL()}
                alt={pet.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center">
                <PawPrint className="h-24 w-24 text-muted-foreground/30" />
              </div>
            )}
          </div>
          {pet.photos.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {pet.photos.slice(1, 5).map((photo, idx) => (
                <div key={idx} className="aspect-square overflow-hidden rounded-lg bg-muted">
                  <img
                    src={photo.getDirectURL()}
                    alt={`${pet.name} ${idx + 2}`}
                    className="h-full w-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pet Information */}
        <div className="space-y-6">
          <div>
            <div className="mb-2 flex items-start justify-between">
              <h1 className="text-4xl font-bold">{pet.name}</h1>
              <Badge className={statusColors[pet.status]}>{pet.status}</Badge>
            </div>
            <p className="text-xl text-muted-foreground">{pet.breed}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-full bg-primary/10 p-2">
                  <PawPrint className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Type</p>
                  <p className="font-semibold">{pet.petType}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-full bg-chart-1/10 p-2">
                  <Calendar className="h-5 w-5 text-chart-1" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Age</p>
                  <p className="font-semibold">{Number(pet.age)} years</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-full bg-chart-2/10 p-2">
                  <Ruler className="h-5 w-5 text-chart-2" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Size</p>
                  <p className="font-semibold">{pet.size}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-3 p-4">
                <div className="rounded-full bg-chart-3/10 p-2">
                  <MapPin className="h-5 w-5 text-chart-3" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-semibold">{pet.location}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="medical">Medical History</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>About {pet.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{pet.description}</p>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="medical" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Medical History</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{pet.medicalHistory}</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {pet.status === 'available' && !isPetOwner && (
            <div className="flex gap-3">
              {isAuthenticated ? (
                <>
                  <Dialog open={showApplicationDialog} onOpenChange={setShowApplicationDialog}>
                    <DialogTrigger asChild>
                      <Button className="flex-1 gap-2" onClick={handleApplicationClick}>
                        <Heart className="h-4 w-4" />
                        Apply to Adopt
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Apply to Adopt {pet.name}</DialogTitle>
                        <DialogDescription>
                          Tell us why you'd be a great match.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="application-message">Your message</Label>
                          <Textarea
                            id="application-message"
                            value={applicationMessage}
                            onChange={(e) => setApplicationMessage(e.target.value)}
                            placeholder="Share your experience with pets, living situation, and why you want to adopt..."
                            rows={6}
                          />
                        </div>
                        <Button
                          onClick={handleSubmitApplication}
                          disabled={submitApplication.isPending || !applicationMessage.trim()}
                          className="w-full"
                        >
                          {submitApplication.isPending ? 'Submitting...' : 'Submit Application'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={showInquiryDialog} onOpenChange={setShowInquiryDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="flex-1 gap-2" onClick={handleInquiryClick}>
                        <MessageCircle className="h-4 w-4" />
                        Send Inquiry
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Send an Inquiry about {pet.name}</DialogTitle>
                        <DialogDescription>
                          Ask any questions about this pet.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="inquiry-message">Your message</Label>
                          <Textarea
                            id="inquiry-message"
                            value={inquiryMessage}
                            onChange={(e) => setInquiryMessage(e.target.value)}
                            placeholder="Ask any questions about this pet..."
                            rows={6}
                          />
                        </div>
                        <Button
                          onClick={handleSubmitInquiry}
                          disabled={submitInquiry.isPending || !inquiryMessage.trim()}
                          className="w-full"
                        >
                          {submitInquiry.isPending ? 'Sending...' : 'Send Inquiry'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </>
              ) : (
                <div className="w-full space-y-3">
                  <div className="rounded-lg border border-dashed bg-muted/50 p-4 text-center">
                    <LogIn className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
                    <p className="mb-3 text-sm font-medium">Sign in to apply for adoption or send an inquiry</p>
                    <Button onClick={() => login()} size="sm" className="gap-2">
                      <LogIn className="h-4 w-4" />
                      Log In
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Edit Pet Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Pet Listing</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <PhotoUpload
              photos={editedPet.photos || []}
              onChange={(photos) => setEditedPet({ ...editedPet, photos })}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-name"
                  value={editedPet.name}
                  onChange={(e) => setEditedPet({ ...editedPet, name: e.target.value })}
                  placeholder="Pet name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-petType">
                  Type <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-petType"
                  value={editedPet.petType}
                  onChange={(e) => setEditedPet({ ...editedPet, petType: e.target.value })}
                  placeholder="Dog, Cat, etc."
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-breed">
                  Breed <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-breed"
                  value={editedPet.breed}
                  onChange={(e) => setEditedPet({ ...editedPet, breed: e.target.value })}
                  placeholder="Breed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-age">Age (years)</Label>
                <Input
                  id="edit-age"
                  type="number"
                  value={Number(editedPet.age)}
                  onChange={(e) => setEditedPet({ ...editedPet, age: BigInt(e.target.value || 0) })}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-size">Size</Label>
                <Select value={editedPet.size} onValueChange={(value) => setEditedPet({ ...editedPet, size: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-location">
                  Location <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-location"
                  value={editedPet.location}
                  onChange={(e) => setEditedPet({ ...editedPet, location: e.target.value })}
                  placeholder="City, State"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status">Adoption Status</Label>
              <Select 
                value={editedPet.status} 
                onValueChange={(value) => setEditedPet({ ...editedPet, status: value as PetStatus })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={PetStatus.available}>Available</SelectItem>
                  <SelectItem value={PetStatus.pending}>Pending</SelectItem>
                  <SelectItem value={PetStatus.adopted}>Adopted</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editedPet.description}
                onChange={(e) => setEditedPet({ ...editedPet, description: e.target.value })}
                placeholder="Describe the pet's personality, behavior, etc."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-medicalHistory">Medical History</Label>
              <Textarea
                id="edit-medicalHistory"
                value={editedPet.medicalHistory}
                onChange={(e) => setEditedPet({ ...editedPet, medicalHistory: e.target.value })}
                placeholder="Vaccinations, health conditions, etc."
                rows={3}
              />
            </div>
            <Button onClick={handleUpdatePet} disabled={updatePet.isPending} className="w-full">
              {updatePet.isPending ? 'Updating...' : 'Update Pet Listing'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <TOSModal
        open={showTOSModal}
        onClose={() => {
          setShowTOSModal(false);
          setPendingAction(null);
        }}
        onAccepted={handleTOSAccepted}
      />

      <BreederWarningModal
        open={showBreederWarning}
        onClose={() => setShowBreederWarning(false)}
      />
    </div>
  );
}
