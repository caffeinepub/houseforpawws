import { useState } from 'react';
import { useGetUserListings, useUpdatePet, useDeleteListing } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { PawPrint, Edit, Trash2, CheckCircle2, Calendar, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { PetStatus } from '../backend';
import PhotoUpload from '../components/PhotoUpload';
import type { PetProfile } from '../backend';

export default function EditYourListingsPage() {
  const { identity } = useInternetIdentity();
  const { data: userListings = [], isLoading } = useGetUserListings(identity?.getPrincipal() || null);
  const updatePet = useUpdatePet();
  const deleteListing = useDeleteListing();

  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedPet, setSelectedPet] = useState<PetProfile | null>(null);
  const [editedPet, setEditedPet] = useState<Partial<PetProfile>>({});

  const handleEditClick = (pet: PetProfile) => {
    setSelectedPet(pet);
    setEditedPet({
      name: pet.name,
      petType: pet.petType,
      age: pet.age,
      breed: pet.breed,
      size: pet.size,
      location: pet.location,
      description: pet.description,
      medicalHistory: pet.medicalHistory,
      photos: pet.photos,
      status: pet.status,
    });
    setShowEditDialog(true);
  };

  const handleDeleteClick = (pet: PetProfile) => {
    setSelectedPet(pet);
    setShowDeleteDialog(true);
  };

  const handleUpdatePet = async () => {
    if (!selectedPet || !editedPet.name || !editedPet.petType || !editedPet.breed || !editedPet.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    const updatedPet: PetProfile = {
      ...selectedPet,
      name: editedPet.name,
      petType: editedPet.petType,
      age: editedPet.age || BigInt(0),
      breed: editedPet.breed,
      size: editedPet.size || 'Medium',
      location: editedPet.location,
      description: editedPet.description || '',
      medicalHistory: editedPet.medicalHistory || '',
      photos: editedPet.photos || [],
      status: editedPet.status || selectedPet.status,
    };

    try {
      await updatePet.mutateAsync({ petId: selectedPet.id, updatedPet });
      toast.success('Pet listing updated successfully!');
      setShowEditDialog(false);
      setSelectedPet(null);
    } catch (error: any) {
      toast.error('Failed to update pet listing');
      console.error(error);
    }
  };

  const handleDeletePet = async () => {
    if (!selectedPet) return;

    try {
      await deleteListing.mutateAsync(selectedPet.id);
      toast.success('Pet listing deleted successfully!');
      setShowDeleteDialog(false);
      setSelectedPet(null);
    } catch (error: any) {
      toast.error('Failed to delete pet listing');
      console.error(error);
    }
  };

  const handleStatusChange = async (pet: PetProfile, newStatus: PetStatus) => {
    const updatedPet: PetProfile = {
      ...pet,
      status: newStatus,
    };

    try {
      await updatePet.mutateAsync({ petId: pet.id, updatedPet });
      toast.success(`Pet marked as ${newStatus}!`);
    } catch (error: any) {
      toast.error('Failed to update pet status');
      console.error(error);
    }
  };

  const statusColors = {
    available: 'bg-green-500/10 text-green-700 dark:text-green-400',
    pending: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400',
    adopted: 'bg-blue-500/10 text-blue-700 dark:text-blue-400',
  };

  if (isLoading) {
    return (
      <div className="container py-8">
        <Skeleton className="mb-6 h-10 w-64" />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-48 w-full rounded-lg" />
              </CardHeader>
              <CardContent>
                <Skeleton className="mb-2 h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold bg-gradient-to-r from-primary via-chart-1 to-primary bg-clip-text text-transparent">
          Edit Your Listings
        </h1>
        <p className="text-muted-foreground">
          Manage your pet adoption listings - edit details, update status, or delete listings
        </p>
      </div>

      {userListings.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <PawPrint className="mb-4 h-16 w-16 text-muted-foreground/50" />
            <h3 className="mb-2 text-xl font-semibold">No listings yet</h3>
            <p className="text-muted-foreground">
              You haven't created any pet listings. Use the floating button on the home page to add your first pet.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="mb-6 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              You have <span className="font-semibold text-foreground">{userListings.length}</span> listing{userListings.length !== 1 ? 's' : ''}
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {userListings.map((pet) => (
              <Card key={pet.id} className="group overflow-hidden transition-all hover:shadow-lg">
                <CardHeader className="p-0">
                  <div className="relative aspect-square overflow-hidden bg-muted">
                    {pet.photos.length > 0 ? (
                      <img
                        src={pet.photos[0].getDirectURL()}
                        alt={pet.name}
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <PawPrint className="h-16 w-16 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute right-2 top-2">
                      <Badge className={statusColors[pet.status]}>{pet.status}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <CardTitle className="mb-2 line-clamp-1">{pet.name}</CardTitle>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p>
                      <span className="font-medium">Breed:</span> {pet.breed}
                    </p>
                    <p>
                      <span className="font-medium">Age:</span> {Number(pet.age)} years
                    </p>
                    <p>
                      <span className="font-medium">Location:</span> {pet.location}
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col gap-2 p-4 pt-0">
                  <div className="flex w-full gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditClick(pet)}
                      className="flex-1 gap-2"
                    >
                      <Edit className="h-4 w-4" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteClick(pet)}
                      className="flex-1 gap-2"
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  </div>
                  <div className="flex w-full flex-wrap gap-1">
                    <Button
                      size="sm"
                      variant={pet.status === PetStatus.available ? 'default' : 'ghost'}
                      onClick={() => handleStatusChange(pet, PetStatus.available)}
                      disabled={pet.status === PetStatus.available || updatePet.isPending}
                      className="flex-1 gap-1 text-xs"
                    >
                      <CheckCircle2 className="h-3 w-3" />
                      Available
                    </Button>
                    <Button
                      size="sm"
                      variant={pet.status === PetStatus.pending ? 'default' : 'ghost'}
                      onClick={() => handleStatusChange(pet, PetStatus.pending)}
                      disabled={pet.status === PetStatus.pending || updatePet.isPending}
                      className="flex-1 gap-1 text-xs"
                    >
                      <Calendar className="h-3 w-3" />
                      Pending
                    </Button>
                    <Button
                      size="sm"
                      variant={pet.status === PetStatus.adopted ? 'default' : 'ghost'}
                      onClick={() => handleStatusChange(pet, PetStatus.adopted)}
                      disabled={pet.status === PetStatus.adopted || updatePet.isPending}
                      className="flex-1 gap-1 text-xs"
                    >
                      <Heart className="h-3 w-3 fill-current" />
                      Adopted
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </>
      )}

      {/* Edit Pet Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Pet Listing</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <PhotoUpload
              photos={editedPet.photos || []}
              onChange={(photos) => setEditedPet({ ...editedPet, photos })}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-name"
                  value={editedPet.name}
                  onChange={(e) => setEditedPet({ ...editedPet, name: e.target.value })}
                  placeholder="Pet name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-petType">
                  Type <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-petType"
                  value={editedPet.petType}
                  onChange={(e) => setEditedPet({ ...editedPet, petType: e.target.value })}
                  placeholder="Dog, Cat, etc."
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-breed">
                  Breed <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-breed"
                  value={editedPet.breed}
                  onChange={(e) => setEditedPet({ ...editedPet, breed: e.target.value })}
                  placeholder="Breed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-age">Age (years)</Label>
                <Input
                  id="edit-age"
                  type="number"
                  value={Number(editedPet.age)}
                  onChange={(e) => setEditedPet({ ...editedPet, age: BigInt(e.target.value || 0) })}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-size">Size</Label>
                <Select value={editedPet.size} onValueChange={(value) => setEditedPet({ ...editedPet, size: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-location">
                  Location <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="edit-location"
                  value={editedPet.location}
                  onChange={(e) => setEditedPet({ ...editedPet, location: e.target.value })}
                  placeholder="City, State"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status">Adoption Status</Label>
              <Select 
                value={editedPet.status} 
                onValueChange={(value) => setEditedPet({ ...editedPet, status: value as PetStatus })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={PetStatus.available}>Available</SelectItem>
                  <SelectItem value={PetStatus.pending}>Pending</SelectItem>
                  <SelectItem value={PetStatus.adopted}>Adopted</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editedPet.description}
                onChange={(e) => setEditedPet({ ...editedPet, description: e.target.value })}
                placeholder="Describe the pet's personality, behavior, etc."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-medicalHistory">Medical History</Label>
              <Textarea
                id="edit-medicalHistory"
                value={editedPet.medicalHistory}
                onChange={(e) => setEditedPet({ ...editedPet, medicalHistory: e.target.value })}
                placeholder="Vaccinations, health conditions, etc."
                rows={3}
              />
            </div>
            <Button onClick={handleUpdatePet} disabled={updatePet.isPending} className="w-full">
              {updatePet.isPending ? 'Updating...' : 'Update Pet Listing'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to delete this listing?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the listing for <strong>{selectedPet?.name}</strong>. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteListing.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeletePet}
              disabled={deleteListing.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteListing.isPending ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
