import { useGetAdminDashboardStats, useIsCallerAdmin } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { PawPrint, Users, FileText, MessageCircle, Mail, CheckCircle, Clock, Heart, UserCheck, UserPlus } from 'lucide-react';

export default function AdminDashboardAnalytics() {
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();
  const { data: stats, isLoading: statsLoading, error } = useGetAdminDashboardStats();

  if (adminLoading || statsLoading) {
    return (
      <div className="container py-8">
        <div className="mb-8">
          <Skeleton className="mb-2 h-10 w-64" />
          <Skeleton className="h-5 w-96" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertDescription>
            Access denied. This page is only accessible to administrators.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container py-8">
        <Alert variant="destructive">
          <AlertDescription>
            Failed to load dashboard statistics. Please try again later.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!stats) {
    return null;
  }

  const petStatusData = [
    { name: 'Available', value: Number(stats.availablePets), color: 'oklch(var(--chart-1))' },
    { name: 'Pending', value: Number(stats.pendingPets), color: 'oklch(var(--chart-3))' },
    { name: 'Adopted', value: Number(stats.adoptedPets), color: 'oklch(var(--chart-2))' },
  ];

  const activityData = [
    { name: 'Applications', value: Number(stats.totalApplications), color: 'oklch(var(--chart-1))' },
    { name: 'Inquiries', value: Number(stats.totalInquiries), color: 'oklch(var(--chart-2))' },
    { name: 'Messages', value: Number(stats.totalMessages), color: 'oklch(var(--chart-3))' },
  ];

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold bg-gradient-to-r from-primary via-chart-1 to-primary bg-clip-text text-transparent">
          Admin Dashboard Analytics
        </h1>
        <p className="text-muted-foreground">
          Comprehensive overview of platform statistics and user engagement
        </p>
      </div>

      {/* Summary Cards */}
      <div className="mb-8 grid gap-4 md:grid-cols-4">
        <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pets</CardTitle>
            <PawPrint className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{Number(stats.totalPets)}</div>
            <p className="mt-1 text-xs text-muted-foreground">All pets in the system</p>
          </CardContent>
        </Card>

        <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Pets</CardTitle>
            <Heart className="h-5 w-5 text-[oklch(var(--chart-1))]" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[oklch(var(--chart-1))]">{Number(stats.availablePets)}</div>
            <p className="mt-1 text-xs text-muted-foreground">Ready for adoption</p>
          </CardContent>
        </Card>

        <Card className="border-chart-3/20 bg-gradient-to-br from-card to-chart-3/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Adoptions</CardTitle>
            <Clock className="h-5 w-5 text-[oklch(var(--chart-3))]" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[oklch(var(--chart-3))]">{Number(stats.pendingPets)}</div>
            <p className="mt-1 text-xs text-muted-foreground">In progress</p>
          </CardContent>
        </Card>

        <Card className="border-chart-2/20 bg-gradient-to-br from-card to-chart-2/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Adopted Pets</CardTitle>
            <CheckCircle className="h-5 w-5 text-[oklch(var(--chart-2))]" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[oklch(var(--chart-2))]">{Number(stats.adoptedPets)}</div>
            <p className="mt-1 text-xs text-muted-foreground">Found homes</p>
          </CardContent>
        </Card>
      </div>

      {/* User & Activity Cards */}
      <div className="mb-8 grid gap-4 md:grid-cols-4">
        <Card className="border-secondary/20 bg-gradient-to-br from-card to-secondary/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">TOS Accepted Users</CardTitle>
            <Users className="h-5 w-5 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-secondary">{Number(stats.totalTOSAcceptedUsers)}</div>
            <p className="mt-1 text-xs text-muted-foreground">Active community members</p>
          </CardContent>
        </Card>

        <Card className="border-chart-1/20 bg-gradient-to-br from-card to-chart-1/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Applications</CardTitle>
            <FileText className="h-5 w-5 text-[oklch(var(--chart-1))]" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[oklch(var(--chart-1))]">{Number(stats.totalApplications)}</div>
            <p className="mt-1 text-xs text-muted-foreground">Adoption requests</p>
          </CardContent>
        </Card>

        <Card className="border-chart-2/20 bg-gradient-to-br from-card to-chart-2/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inquiries</CardTitle>
            <Mail className="h-5 w-5 text-[oklch(var(--chart-2))]" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[oklch(var(--chart-2))]">{Number(stats.totalInquiries)}</div>
            <p className="mt-1 text-xs text-muted-foreground">Questions received</p>
          </CardContent>
        </Card>

        <Card className="border-chart-3/20 bg-gradient-to-br from-card to-chart-3/5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Messages</CardTitle>
            <MessageCircle className="h-5 w-5 text-[oklch(var(--chart-3))]" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[oklch(var(--chart-3))]">{Number(stats.totalMessages)}</div>
            <p className="mt-1 text-xs text-muted-foreground">Chat conversations</p>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced User Analytics Table */}
      <Card className="mb-6 border-primary/20 bg-gradient-to-br from-card to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            User Analytics - TOS Accepted Users
          </CardTitle>
        </CardHeader>
        <CardContent>
          {stats.userAnalytics.length === 0 ? (
            <p className="text-sm text-muted-foreground">No users have accepted the Terms of Service yet.</p>
          ) : (
            <ScrollArea className="h-[400px] rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Email</TableHead>
                    <TableHead>Full Name</TableHead>
                    <TableHead>Display Name</TableHead>
                    <TableHead>User Type</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.userAnalytics.map((user, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          {user.email}
                        </div>
                      </TableCell>
                      <TableCell>{user.fullName}</TableCell>
                      <TableCell>{user.displayName}</TableCell>
                      <TableCell>
                        {user.userType === 'Adopting' ? (
                          <Badge variant="default" className="bg-[oklch(var(--chart-1))] hover:bg-[oklch(var(--chart-1))]/90">
                            <UserCheck className="mr-1 h-3 w-3" />
                            Adopting
                          </Badge>
                        ) : user.userType === 'Putting for Adoption' ? (
                          <Badge variant="secondary" className="bg-[oklch(var(--chart-2))] hover:bg-[oklch(var(--chart-2))]/90 text-white">
                            <UserPlus className="mr-1 h-3 w-3" />
                            Putting for Adoption
                          </Badge>
                        ) : (
                          <Badge variant="outline">Unknown</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Pet Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={petStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {petStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>User Activity Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--border))" />
                <XAxis dataKey="name" stroke="oklch(var(--foreground))" />
                <YAxis stroke="oklch(var(--foreground))" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'oklch(var(--card))',
                    border: '1px solid oklch(var(--border))',
                    borderRadius: '0.5rem',
                  }}
                />
                <Legend />
                <Bar dataKey="value" name="Count" radius={[8, 8, 0, 0]}>
                  {activityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Success Rate Card */}
      <Card className="mt-6 border-primary/20 bg-gradient-to-br from-card to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-primary" />
            Adoption Success Rate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-4xl font-bold text-primary">
                {stats.totalPets > 0
                  ? Math.round((Number(stats.adoptedPets) / Number(stats.totalPets)) * 100)
                  : 0}
                %
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {Number(stats.adoptedPets)} out of {Number(stats.totalPets)} pets have found loving homes
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-semibold text-[oklch(var(--chart-1))]">
                {Number(stats.availablePets)}
              </div>
              <p className="text-sm text-muted-foreground">Still waiting</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
