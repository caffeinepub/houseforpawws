import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Bell, Moon, Globe } from 'lucide-react';
import { useTheme } from 'next-themes';
import type { View } from '../App';

interface SettingsPageProps {
  onNavigate: (view: View) => void;
}

export default function SettingsPage({ onNavigate }: SettingsPageProps) {
  const { theme, setTheme } = useTheme();

  return (
    <div className="container py-8">
      <div className="mx-auto max-w-2xl space-y-6">
        <Button variant="ghost" onClick={() => onNavigate('home')} className="gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Settings</CardTitle>
            <CardDescription>Manage your application preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-lg font-medium">
                <Moon className="h-5 w-5 text-primary" />
                Appearance
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="dark-mode">Dark Mode</Label>
                    <p className="text-sm text-muted-foreground">Toggle between light and dark theme</p>
                  </div>
                  <Switch
                    id="dark-mode"
                    checked={theme === 'dark'}
                    onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
                  />
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="mb-4 flex items-center gap-2 text-lg font-medium">
                <Bell className="h-5 w-5 text-primary" />
                Notifications
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive updates about your adoption applications
                    </p>
                  </div>
                  <Switch id="email-notifications" disabled />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="new-pets">New Pet Alerts</Label>
                    <p className="text-sm text-muted-foreground">Get notified when new pets are available</p>
                  </div>
                  <Switch id="new-pets" disabled />
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="mb-4 flex items-center gap-2 text-lg font-medium">
                <Globe className="h-5 w-5 text-primary" />
                Preferences
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="save-filters">Save Search Filters</Label>
                    <p className="text-sm text-muted-foreground">Remember your pet search preferences</p>
                  </div>
                  <Switch id="save-filters" disabled />
                </div>
              </div>
            </div>

            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-sm text-muted-foreground">
                <strong>Note:</strong> Some settings are currently placeholders and will be fully functional in a future
                update.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
