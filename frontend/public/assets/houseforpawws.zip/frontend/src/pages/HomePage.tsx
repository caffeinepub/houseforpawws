import { useState, useMemo } from 'react';
import { useGetAvailablePets, useAddPet, useCanUsePlatformFeatures, useGetCallerUserProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Search, PawPrint, Heart, Plus, X, SlidersHorizontal } from 'lucide-react';
import { toast } from 'sonner';
import { PetStatus } from '../backend';
import TOSModal from '../components/TOSModal';
import CaptchaModal from '../components/CaptchaModal';
import PhotoUpload from '../components/PhotoUpload';
import type { View } from '../App';
import type { PetProfile } from '../backend';

interface HomePageProps {
  onNavigate: (view: View, petId?: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const { data: pets = [], isLoading } = useGetAvailablePets();
  const { identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: canUseFeatures = false, isLoading: featuresLoading } = useCanUsePlatformFeatures();
  const addPet = useAddPet();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  
  // Advanced filter states
  const [ageRange, setAgeRange] = useState<[number, number]>([0, 20]);
  const [filterLocation, setFilterLocation] = useState('');
  const [filterBreed, setFilterBreed] = useState('all');
  const [filterSize, setFilterSize] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const [showAddPetDialog, setShowAddPetDialog] = useState(false);
  const [showTOSModal, setShowTOSModal] = useState(false);
  const [showCaptchaModal, setShowCaptchaModal] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const [tosAccepted, setTosAccepted] = useState(false);
  const [newPet, setNewPet] = useState<Partial<PetProfile>>({
    name: '',
    petType: '',
    age: BigInt(0),
    breed: '',
    size: '',
    location: '',
    description: '',
    medicalHistory: '',
    photos: [],
  });

  const isAuthenticated = !!identity;

  // Extract unique values for filter dropdowns
  const petTypes = useMemo(() => Array.from(new Set(pets.map((p) => p.petType))), [pets]);
  const breeds = useMemo(() => Array.from(new Set(pets.map((p) => p.breed))).sort(), [pets]);
  const sizes = useMemo(() => Array.from(new Set(pets.map((p) => p.size))).sort(), [pets]);

  // Combined filtering logic
  const filteredPets = useMemo(() => {
    return pets.filter((pet) => {
      // Search term filter
      const matchesSearch =
        pet.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pet.breed.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pet.location.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Pet type filter
      const matchesType = filterType === 'all' || pet.petType.toLowerCase() === filterType.toLowerCase();
      
      // Age range filter
      const petAge = Number(pet.age);
      const matchesAge = petAge >= ageRange[0] && petAge <= ageRange[1];
      
      // Location filter
      const matchesLocation = !filterLocation || pet.location.toLowerCase().includes(filterLocation.toLowerCase());
      
      // Breed filter
      const matchesBreed = filterBreed === 'all' || pet.breed === filterBreed;
      
      // Size filter
      const matchesSize = filterSize === 'all' || pet.size === filterSize;
      
      return matchesSearch && matchesType && matchesAge && matchesLocation && matchesBreed && matchesSize;
    });
  }, [pets, searchTerm, filterType, ageRange, filterLocation, filterBreed, filterSize]);

  // Check if any advanced filters are active
  const hasActiveFilters = 
    ageRange[0] !== 0 || 
    ageRange[1] !== 20 || 
    filterLocation !== '' || 
    filterBreed !== 'all' || 
    filterSize !== 'all' ||
    filterType !== 'all' ||
    searchTerm !== '';

  const clearAllFilters = () => {
    setSearchTerm('');
    setFilterType('all');
    setAgeRange([0, 20]);
    setFilterLocation('');
    setFilterBreed('all');
    setFilterSize('all');
  };

  const handleAddPetClick = () => {
    setCaptchaVerified(false);
    setTosAccepted(false);
    setShowCaptchaModal(true);
  };

  const handleCaptchaVerified = () => {
    setShowCaptchaModal(false);
    setCaptchaVerified(true);
    setShowTOSModal(true);
  };

  const handleTOSAccepted = () => {
    setShowTOSModal(false);
    setTosAccepted(true);
    setShowAddPetDialog(true);
  };

  const handleAddPet = async () => {
    if (!newPet.name || !newPet.petType || !newPet.breed || !newPet.location) {
      toast.error('Please fill in all required fields including location');
      return;
    }

    const pet: PetProfile = {
      id: `pet-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: newPet.name,
      petType: newPet.petType,
      age: newPet.age || BigInt(0),
      breed: newPet.breed,
      size: newPet.size || 'Medium',
      location: newPet.location,
      description: newPet.description || '',
      medicalHistory: newPet.medicalHistory || '',
      photos: newPet.photos || [],
      status: PetStatus.available,
      createdAt: BigInt(Date.now() * 1000000),
      isHidden: false,
    };

    try {
      await addPet.mutateAsync(pet);
      toast.success('Pet added successfully!');
      setShowAddPetDialog(false);
      setNewPet({
        name: '',
        petType: '',
        age: BigInt(0),
        breed: '',
        size: '',
        location: '',
        description: '',
        medicalHistory: '',
        photos: [],
      });
      setCaptchaVerified(false);
      setTosAccepted(false);
    } catch (error: any) {
      if (error?.message?.includes('Terms of Service') || error?.message?.includes('display name')) {
        toast.error('You must accept the Terms of Service and set a display name before uploading pets.');
        setShowAddPetDialog(false);
        setCaptchaVerified(false);
        setTosAccepted(false);
      } else {
        toast.error('Failed to add pet');
        console.error(error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b bg-gradient-to-br from-primary/5 via-chart-1/5 to-chart-2/5 py-20">
        <div className="container relative z-10">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              <Heart className="h-4 w-4 fill-current" />
              Find Your Perfect Companion
            </div>
            <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              Give a Pet a{' '}
              <span className="bg-gradient-to-r from-primary via-chart-1 to-chart-2 bg-clip-text text-transparent">
                Forever Home
              </span>
            </h1>
            <p className="mb-8 text-lg text-muted-foreground">
              Every pet deserves love and care. Browse our available pets and find your new best friend today.
            </p>
            {!isAuthenticated && (
              <p className="text-sm text-muted-foreground">
                <span className="font-medium">Browse freely!</span> Sign up to apply for adoption or contact pet owners.
              </p>
            )}
          </div>
        </div>
        <div className="absolute inset-0 -z-0 opacity-20">
          <div className="absolute left-1/4 top-1/4 h-64 w-64 rounded-full bg-primary blur-3xl" />
          <div className="absolute right-1/4 bottom-1/4 h-64 w-64 rounded-full bg-chart-1 blur-3xl" />
        </div>
      </section>

      {/* Search and Filter */}
      <section className="border-b bg-background py-8">
        <div className="container">
          <div className="mx-auto max-w-6xl space-y-4">
            {/* Basic Search and Type Filter */}
            <div className="flex flex-col gap-4 sm:flex-row">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by name, breed, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {petTypes.map((type) => (
                    <SelectItem key={type} value={type.toLowerCase()}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="w-full sm:w-auto"
              >
                <SlidersHorizontal className="mr-2 h-4 w-4" />
                Advanced Filters
              </Button>
            </div>

            {/* Advanced Filters Panel */}
            {showFilters && (
              <div className="rounded-lg border bg-gradient-to-br from-primary/5 via-chart-1/5 to-chart-2/5 p-6 shadow-sm">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Advanced Filters</h3>
                  {hasActiveFilters && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearAllFilters}
                      className="text-primary hover:text-primary/80"
                    >
                      <X className="mr-1 h-4 w-4" />
                      Clear All
                    </Button>
                  )}
                </div>
                
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                  {/* Age Range Filter */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium">
                      Age Range: {ageRange[0]} - {ageRange[1]} years
                    </Label>
                    <Slider
                      min={0}
                      max={20}
                      step={1}
                      value={ageRange}
                      onValueChange={(value) => setAgeRange(value as [number, number])}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>0 years</span>
                      <span>20 years</span>
                    </div>
                  </div>

                  {/* Location Filter */}
                  <div className="space-y-3">
                    <Label htmlFor="location-filter" className="text-sm font-medium">
                      Location
                    </Label>
                    <Input
                      id="location-filter"
                      placeholder="Enter location..."
                      value={filterLocation}
                      onChange={(e) => setFilterLocation(e.target.value)}
                      className="w-full"
                    />
                  </div>

                  {/* Breed Filter */}
                  <div className="space-y-3">
                    <Label htmlFor="breed-filter" className="text-sm font-medium">
                      Breed
                    </Label>
                    <Select value={filterBreed} onValueChange={setFilterBreed}>
                      <SelectTrigger id="breed-filter">
                        <SelectValue placeholder="All Breeds" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Breeds</SelectItem>
                        {breeds.map((breed) => (
                          <SelectItem key={breed} value={breed}>
                            {breed}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Size Filter */}
                  <div className="space-y-3">
                    <Label htmlFor="size-filter" className="text-sm font-medium">
                      Size
                    </Label>
                    <Select value={filterSize} onValueChange={setFilterSize}>
                      <SelectTrigger id="size-filter">
                        <SelectValue placeholder="All Sizes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Sizes</SelectItem>
                        {sizes.map((size) => (
                          <SelectItem key={size} value={size}>
                            {size}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* Active Filters Display */}
            {hasActiveFilters && (
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm text-muted-foreground">Active filters:</span>
                {searchTerm && (
                  <Badge variant="secondary" className="gap-1">
                    Search: {searchTerm}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => setSearchTerm('')}
                    />
                  </Badge>
                )}
                {filterType !== 'all' && (
                  <Badge variant="secondary" className="gap-1">
                    Type: {filterType}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => setFilterType('all')}
                    />
                  </Badge>
                )}
                {(ageRange[0] !== 0 || ageRange[1] !== 20) && (
                  <Badge variant="secondary" className="gap-1">
                    Age: {ageRange[0]}-{ageRange[1]} years
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => setAgeRange([0, 20])}
                    />
                  </Badge>
                )}
                {filterLocation && (
                  <Badge variant="secondary" className="gap-1">
                    Location: {filterLocation}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => setFilterLocation('')}
                    />
                  </Badge>
                )}
                {filterBreed !== 'all' && (
                  <Badge variant="secondary" className="gap-1">
                    Breed: {filterBreed}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => setFilterBreed('all')}
                    />
                  </Badge>
                )}
                {filterSize !== 'all' && (
                  <Badge variant="secondary" className="gap-1">
                    Size: {filterSize}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => setFilterSize('all')}
                    />
                  </Badge>
                )}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Pet Grid */}
      <section className="relative py-12">
        <div className="container">
          {isLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-48 w-full rounded-lg" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="mb-2 h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredPets.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <PawPrint className="mb-4 h-16 w-16 text-muted-foreground/50" />
              <h3 className="mb-2 text-xl font-semibold">No pets found</h3>
              <p className="text-muted-foreground">
                {hasActiveFilters
                  ? 'Try adjusting your search or filters'
                  : 'Check back soon for new pets available for adoption'}
              </p>
              {hasActiveFilters && (
                <Button
                  variant="outline"
                  onClick={clearAllFilters}
                  className="mt-4"
                >
                  Clear All Filters
                </Button>
              )}
            </div>
          ) : (
            <>
              <div className="mb-6 flex items-center justify-between">
                <h2 className="text-2xl font-bold">
                  Available Pets <span className="text-muted-foreground">({filteredPets.length})</span>
                </h2>
              </div>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {filteredPets.map((pet) => (
                  <PetCard key={pet.id} pet={pet} onViewDetails={() => onNavigate('pet-detail', pet.id)} />
                ))}
              </div>
            </>
          )}
        </div>

        {/* Floating Add Animal Button */}
        {isAuthenticated && !featuresLoading && (
          <button
            onClick={handleAddPetClick}
            className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary via-chart-1 to-chart-2 text-white shadow-lg transition-all duration-300 hover:scale-110 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-primary/50 active:scale-95 sm:h-16 sm:w-16"
            aria-label="Add Animal for Adoption"
          >
            <img
              src="/assets/generated/paw-icon-transparent.dim_64x64.png"
              alt="Add Pet"
              className="h-7 w-7 sm:h-8 sm:w-8"
            />
            <div className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-accent shadow-md">
              <Plus className="h-4 w-4 text-accent-foreground" />
            </div>
          </button>
        )}
      </section>

      {/* Add Pet Dialog */}
      <Dialog open={showAddPetDialog} onOpenChange={setShowAddPetDialog}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Animal for Adoption</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <PhotoUpload
              photos={newPet.photos || []}
              onChange={(photos) => setNewPet({ ...newPet, photos })}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">
                  Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="name"
                  value={newPet.name}
                  onChange={(e) => setNewPet({ ...newPet, name: e.target.value })}
                  placeholder="Pet name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="petType">
                  Type <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="petType"
                  value={newPet.petType}
                  onChange={(e) => setNewPet({ ...newPet, petType: e.target.value })}
                  placeholder="Dog, Cat, etc."
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="breed">
                  Breed <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="breed"
                  value={newPet.breed}
                  onChange={(e) => setNewPet({ ...newPet, breed: e.target.value })}
                  placeholder="Breed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="age">Age (years)</Label>
                <Input
                  id="age"
                  type="number"
                  value={Number(newPet.age)}
                  onChange={(e) => setNewPet({ ...newPet, age: BigInt(e.target.value || 0) })}
                  placeholder="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="size">Size</Label>
                <Select value={newPet.size} onValueChange={(value) => setNewPet({ ...newPet, size: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Small">Small</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">
                  Location <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="location"
                  value={newPet.location}
                  onChange={(e) => setNewPet({ ...newPet, location: e.target.value })}
                  placeholder="City, State"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newPet.description}
                onChange={(e) => setNewPet({ ...newPet, description: e.target.value })}
                placeholder="Describe the pet's personality, behavior, etc."
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="medicalHistory">Medical History</Label>
              <Textarea
                id="medicalHistory"
                value={newPet.medicalHistory}
                onChange={(e) => setNewPet({ ...newPet, medicalHistory: e.target.value })}
                placeholder="Vaccinations, health conditions, etc."
                rows={3}
              />
            </div>
            <Button onClick={handleAddPet} disabled={addPet.isPending} className="w-full">
              {addPet.isPending ? 'Adding...' : 'Add Pet'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* CAPTCHA Modal */}
      <CaptchaModal
        open={showCaptchaModal}
        onClose={() => {
          setShowCaptchaModal(false);
          setCaptchaVerified(false);
        }}
        onVerified={handleCaptchaVerified}
        title="Upload Verification"
        description="Please complete this verification before uploading a pet."
      />

      {/* TOS Modal */}
      <TOSModal
        open={showTOSModal}
        onClose={() => {
          setShowTOSModal(false);
          setCaptchaVerified(false);
          setTosAccepted(false);
        }}
        onAccepted={handleTOSAccepted}
      />
    </div>
  );
}

function PetCard({ pet, onViewDetails }: { pet: PetProfile; onViewDetails: () => void }) {
  const imageUrl = pet.photos.length > 0 ? pet.photos[0].getDirectURL() : null;

  return (
    <Card className="group overflow-hidden transition-all hover:shadow-lg">
      <CardHeader className="p-0">
        <div className="relative aspect-square overflow-hidden bg-muted">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={pet.name}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center">
              <PawPrint className="h-16 w-16 text-muted-foreground/30" />
            </div>
          )}
          <div className="absolute right-2 top-2">
            <Badge variant="secondary" className="bg-background/90 backdrop-blur">
              {pet.petType}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <CardTitle className="mb-2 line-clamp-1">{pet.name}</CardTitle>
        <div className="space-y-1 text-sm text-muted-foreground">
          <p>
            <span className="font-medium">Breed:</span> {pet.breed}
          </p>
          <p>
            <span className="font-medium">Age:</span> {Number(pet.age)} years
          </p>
          <p>
            <span className="font-medium">Location:</span> {pet.location}
          </p>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button onClick={onViewDetails} className="w-full">
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
}
