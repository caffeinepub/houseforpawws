import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile, useCanUsePlatformFeatures } from './hooks/useQueries';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import PetDetailPage from './pages/PetDetailPage';
import MyApplicationsPage from './pages/MyApplicationsPage';
import AdminDashboard from './pages/AdminDashboard';
import AdminDashboardAnalytics from './pages/AdminDashboardAnalytics';
import AdminModerationPage from './pages/AdminModerationPage';
import EditYourListingsPage from './pages/EditYourListingsPage';
import ViewProfilePage from './pages/ViewProfilePage';
import EditProfilePage from './pages/EditProfilePage';
import SettingsPage from './pages/SettingsPage';
import InboxPage from './pages/InboxPage';
import ChatPage from './pages/ChatPage';
import ProfileSetupModal from './components/ProfileSetupModal';
import TOSModal from './components/TOSModal';
import { Toaster } from '@/components/ui/sonner';
import { ThemeProvider } from 'next-themes';
import { useState, useEffect } from 'react';
import type { Principal } from '@icp-sdk/core/principal';

export type View = 'home' | 'pet-detail' | 'my-applications' | 'admin' | 'admin-analytics' | 'admin-moderation' | 'edit-listings' | 'view-profile' | 'edit-profile' | 'settings' | 'inbox' | 'chat';

function App() {
  const { identity } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const { data: canUsePlatformFeatures, isLoading: featuresLoading } = useCanUsePlatformFeatures();
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);
  const [selectedChatUser, setSelectedChatUser] = useState<Principal | null>(null);
  const [showPostLoginTOS, setShowPostLoginTOS] = useState(false);

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  // Check if user needs to accept TOS after login
  useEffect(() => {
    if (isAuthenticated && !profileLoading && !featuresLoading && userProfile !== null) {
      // User is logged in and has a profile, check if they need to accept TOS
      // Only show TOS modal if canUsePlatformFeatures is explicitly false
      if (canUsePlatformFeatures === false) {
        setShowPostLoginTOS(true);
      } else if (canUsePlatformFeatures === true) {
        // User has accepted TOS, ensure modal is closed
        setShowPostLoginTOS(false);
      }
    } else if (!isAuthenticated) {
      // User logged out, reset TOS modal state
      setShowPostLoginTOS(false);
    }
  }, [isAuthenticated, profileLoading, featuresLoading, userProfile, canUsePlatformFeatures]);

  const handleNavigate = (view: View, petId?: string, chatUser?: Principal) => {
    setCurrentView(view);
    if (petId) {
      setSelectedPetId(petId);
    }
    if (chatUser) {
      setSelectedChatUser(chatUser);
    }
  };

  const handleTOSAccepted = () => {
    setShowPostLoginTOS(false);
  };

  const renderView = () => {
    switch (currentView) {
      case 'pet-detail':
        return selectedPetId ? (
          <PetDetailPage petId={selectedPetId} onBack={() => handleNavigate('home')} onNavigate={handleNavigate} />
        ) : (
          <HomePage onNavigate={handleNavigate} />
        );
      case 'my-applications':
        return <MyApplicationsPage onNavigate={handleNavigate} />;
      case 'admin':
        return <AdminDashboard onNavigate={handleNavigate} />;
      case 'admin-analytics':
        return <AdminDashboardAnalytics />;
      case 'admin-moderation':
        return <AdminModerationPage />;
      case 'edit-listings':
        return <EditYourListingsPage />;
      case 'view-profile':
        return <ViewProfilePage onNavigate={handleNavigate} />;
      case 'edit-profile':
        return <EditProfilePage onNavigate={handleNavigate} />;
      case 'settings':
        return <SettingsPage onNavigate={handleNavigate} />;
      case 'inbox':
        return <InboxPage onNavigate={handleNavigate} />;
      case 'chat':
        return selectedChatUser ? (
          <ChatPage otherUser={selectedChatUser} onBack={() => handleNavigate('inbox')} />
        ) : (
          <InboxPage onNavigate={handleNavigate} />
        );
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <div className="flex min-h-screen flex-col">
        <Header currentView={currentView} onNavigate={handleNavigate} />
        <main className="flex-1">{renderView()}</main>
        <Footer />
        {showProfileSetup && <ProfileSetupModal />}
        {showPostLoginTOS && (
          <TOSModal
            open={showPostLoginTOS}
            onClose={() => {}}
            onAccepted={handleTOSAccepted}
          />
        )}
        <Toaster />
      </div>
    </ThemeProvider>
  );
}

export default App;
