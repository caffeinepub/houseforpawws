# House for Pawws - Production Deployment Guide

## Publishing Checklist

This document outlines the steps to publish the House for Pawws application to production under the branded URL: **https://houseforpawws.caffeine.xyz**

### Pre-Publish Verification

1. **Code Review**
   - ✅ All frontend files are up to date with latest changes
   - ✅ Backend canister is deployed and stable
   - ✅ All features tested in draft/staging environment

2. **Branding Verification**
   - ✅ App name is "House for Pawws" (not "House for Paws Duplicate")
   - ✅ HTML title tag updated to "House for Pawws - Pet Adoption Platform"
   - ✅ Favicon/app icon set to paw-icon-transparent.dim_64x64.png
   - ✅ Open Graph and social media meta tags configured
   - ✅ Canonical URL points to https://houseforpawws.caffeine.xyz

3. **URL Configuration**
   - ✅ Project slug renamed to "houseforpawws"
   - ✅ Production URL: https://houseforpawws.caffeine.xyz
   - ✅ All metadata references the production URL

### Publishing Steps

1. **Build the Application**
   ```bash
   npm run build
   ```

2. **Deploy to Production**
   - Use the Caffeine.ai platform's publish command
   - Ensure the deployment targets the "houseforpawws" project slug
   - Verify the build completes successfully

3. **Post-Deployment Verification**
   - [ ] Visit https://houseforpawws.caffeine.xyz
   - [ ] Verify the page loads without errors
   - [ ] Check that the page title shows "House for Pawws - Pet Adoption Platform"
   - [ ] Verify the favicon displays correctly
   - [ ] Test login/logout functionality
   - [ ] Test core features (browse pets, view details, submit applications)
   - [ ] Verify admin dashboard access (for admin users)
   - [ ] Test on mobile devices for responsive design

4. **Production State Confirmation**
   - [ ] App is accessible at the production URL (not draft-only)
   - [ ] No "draft expired" or "no draft available" messages
   - [ ] App remains accessible after closing/reopening browser
   - [ ] Bookmarking the URL works correctly

### Troubleshooting

**Issue: "No draft available" message**
- Solution: Ensure the app is published to production, not just deployed as a draft
- Verify the project slug is correctly set to "houseforpawws"

**Issue: Old URL still showing**
- Solution: Clear browser cache and hard refresh (Ctrl+Shift+R or Cmd+Shift+R)
- Verify DNS propagation for the new slug

**Issue: Favicon not displaying**
- Solution: Verify the asset exists at `/assets/generated/paw-icon-transparent.dim_64x64.png`
- Clear browser cache and reload

### Rollback Plan

If issues arise after deployment:
1. Document the specific error or issue
2. Revert to the previous stable version if necessary
3. Investigate and fix the issue in a draft environment
4. Re-deploy once verified

### Notes

- The app uses Internet Identity for authentication
- All user data and pet listings are stored on the Internet Computer blockchain
- The backend canister must remain deployed and accessible for the frontend to function
- Regular backups of canister state are recommended (handled by IC infrastructure)

---

**Last Updated:** February 9, 2026
**Production URL:** https://houseforpawws.caffeine.xyz
**Project Slug:** houseforpawws
