# Specification

## Summary
**Goal:** Add a dedicated “Home” button in the top-left header navigation that takes users to the Home view and shows an active state when Home is selected.

**Planned changes:**
- Add a visible “Home” button in the header’s top-left area near the existing “House for Pawws” brand/logo.
- Wire the “Home” button to navigate to the Home view (same behavior as setting view = `home`), for both logged-out and logged-in users.
- Apply an active/selected visual state to the “Home” button when the current view is Home, consistent with existing navigation button styling.
- Keep the existing brand/logo control present and functional (it should still navigate home).

**User-visible outcome:** Users see a “Home” button in the top-left of the header; clicking it always returns to Home, and it appears selected when they are on the Home view.
