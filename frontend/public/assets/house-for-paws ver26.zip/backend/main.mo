import Map "mo:core/Map";
import List "mo:core/List";
import Order "mo:core/Order";
import Int "mo:core/Int";
import Text "mo:core/Text";
import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import Storage "blob-storage/Storage";
import MixinStorage "blob-storage/Mixin";
import AccessControl "authorization/access-control";
import MixinAuthorization "authorization/MixinAuthorization";

actor {
  include MixinStorage();

  type ChatMessage = {
    sender : Principal;
    content : Text;
    timestamp : Int;
  };

  module ChatMessage {
    public func compareByTimestamp(msg1 : ChatMessage, msg2 : ChatMessage) : Order.Order {
      Int.compare(msg1.timestamp, msg2.timestamp);
    };
  };

  public type UserSettings = {
    profileVisibility : { #public_; #private_ };
    notificationPreferences : Text;
    theme : { #light; #pastel };
  };

  public type UserProfile = {
    avatar : ?Storage.ExternalBlob;
    bio : Text;
    city : Text;
    role : UserRole;
    isVerified : Bool;
  };

  public type UserRole = { #owner; #adopter };

  public type AnimalProfile = {
    photo : Storage.ExternalBlob;
    name : Text;
    age : Nat;
    bio : Text;
    city : Text;
    ownerContact : Principal;
    isVerified : Bool;
  };

  module AnimalProfile {
    public func compare(animal1 : (Principal, AnimalProfile), animal2 : (Principal, AnimalProfile)) : Order.Order {
      switch (Text.compare(animal1.1.city, animal2.1.city)) {
        case (#equal) { Text.compare(animal1.1.name, animal2.1.name) };
        case (order) { order };
      };
    };
  };

  let animals = Map.empty<Principal, AnimalProfile>();
  let userProfiles = Map.empty<Principal, UserProfile>();
  let userSettings = Map.empty<Principal, UserSettings>();
  let followers = Map.empty<Principal, List.List<Principal>>();
  let following = Map.empty<Principal, List.List<Principal>>();
  let messages = Map.empty<Principal, List.List<ChatMessage>>();
  let conversationParticipants = Map.empty<Principal, (Principal, Principal)>();

  // Helper function to check if user is verified
  private func isUserVerified(user : Principal) : Bool {
    switch (userProfiles.get(user)) {
      case (?profile) { profile.isVerified };
      case (null) { false };
    };
  };

  // Helper function to check if user exists
  private func userExists(user : Principal) : Bool {
    switch (userProfiles.get(user)) {
      case (?_) { true };
      case (null) { false };
    };
  };

  // Helper function to check if profile is visible to caller
  private func isProfileVisible(profileOwner : Principal, caller : Principal) : Bool {
    if (AccessControl.isAdmin(accessControlState, caller)) {
      return true;
    };
    if (profileOwner == caller) {
      return true;
    };
    switch (userSettings.get(profileOwner)) {
      case (?settings) {
        switch (settings.profileVisibility) {
          case (#public_) { true };
          case (#private_) { false };
        };
      };
      case (null) { true };
    };
  };

  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  public query ({ caller }) func getAnimalProfile(animalId : Principal) : async AnimalProfile {
    switch (animals.get(animalId)) {
      case (?animal) { animal };
      case (null) { Runtime.trap("Animal profile not found") };
    };
  };

  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can access this");
    };
    userProfiles.get(caller);
  };

  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view profiles");
    };
    if (not isProfileVisible(user, caller)) {
      Runtime.trap("Unauthorized: This profile is private");
    };
    userProfiles.get(user);
  };

  public query ({ caller }) func getFollowers(user : Principal) : async [Principal] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view followers");
    };
    if (not isProfileVisible(user, caller)) {
      Runtime.trap("Unauthorized: This profile is private");
    };
    switch (followers.get(user)) {
      case (?followerList) { followerList.toArray() };
      case (null) { [] };
    };
  };

  public query ({ caller }) func getFollowing(user : Principal) : async [Principal] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view following list");
    };
    if (not isProfileVisible(user, caller)) {
      Runtime.trap("Unauthorized: This profile is private");
    };
    switch (following.get(user)) {
      case (?followingList) { followingList.toArray() };
      case (null) { [] };
    };
  };

  public query ({ caller }) func getAllAnimals() : async [(Principal, AnimalProfile)] {
    animals.toArray().sort();
  };

  public query ({ caller }) func getAnimalsByCity(city : Text) : async [(Principal, AnimalProfile)] {
    let filtered = animals.toArray().filter(
      func((_, animal)) { Text.equal(animal.city, city) }
    );
    filtered.sort();
  };

  /// Removed case normalization from search logic due to core library limitation.
  public query ({ caller }) func searchUserProfiles(searchTerm : Text) : async [(Principal, UserProfile)] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can search profiles");
    };
    // Directly search by term (case-sensitive)
    let results = userProfiles.toArray().filter(
      func((userId, profile)) {
        if (not isProfileVisible(userId, caller)) {
          return false;
        };
        let matchesBio = profile.bio.contains(#text searchTerm);
        let matchesCity = profile.city.contains(#text searchTerm);
        let matchesRole = switch (profile.role) {
          case (#owner) { "owner".contains(#text searchTerm) };
          case (#adopter) { "adopter".contains(#text searchTerm) };
        };
        matchesBio or matchesCity or matchesRole;
      }
    );
    results;
  };

  public query ({ caller }) func getMessages(conversationId : Principal) : async [ChatMessage] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view messages");
    };
    if (AccessControl.isAdmin(accessControlState, caller)) {
      switch (messages.get(conversationId)) {
        case (?messageList) { return messageList.toArray().sort(ChatMessage.compareByTimestamp) };
        case (null) { return [] };
      };
    };
    switch (conversationParticipants.get(conversationId)) {
      case (?(user1, user2)) {
        if (caller != user1 and caller != user2) {
          Runtime.trap("Unauthorized: Can only view your own conversations");
        };
      };
      case (null) {
        Runtime.trap("Conversation not found");
      };
    };
    switch (messages.get(conversationId)) {
      case (?messageList) { messageList.toArray().sort(ChatMessage.compareByTimestamp) };
      case (null) { [] };
    };
  };

  public query ({ caller }) func getCallerUserSettings() : async ?UserSettings {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can access settings");
    };
    userSettings.get(caller);
  };

  public shared ({ caller }) func saveCallerUserProfile(profile : UserProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };
    userProfiles.add(caller, profile);
  };

  public shared ({ caller }) func saveCallerUserSettings(settings : UserSettings) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save settings");
    };
    userSettings.add(caller, settings);
  };

  public shared ({ caller }) func createAnimalProfile(profile : AnimalProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can create animal profiles");
    };
    if (not isUserVerified(caller)) {
      Runtime.trap("Unauthorized: Only verified users can post animals for adoption");
    };
    // Force ownerContact to be the caller - prevent impersonation
    let safeProfile : AnimalProfile = {
      photo = profile.photo;
      name = profile.name;
      age = profile.age;
      bio = profile.bio;
      city = profile.city;
      ownerContact = caller;
      isVerified = profile.isVerified;
    };
    animals.add(caller, safeProfile);
  };

  public shared ({ caller }) func updateAnimalProfile(animalId : Principal, profile : AnimalProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can update animal profiles");
    };
    switch (animals.get(animalId)) {
      case (?existingAnimal) {
        if (existingAnimal.ownerContact != caller and not AccessControl.isAdmin(accessControlState, caller)) {
          Runtime.trap("Unauthorized: Can only update your own animal profiles");
        };
        // Prevent changing owner unless admin
        let safeProfile : AnimalProfile = {
          photo = profile.photo;
          name = profile.name;
          age = profile.age;
          bio = profile.bio;
          city = profile.city;
          ownerContact = if (AccessControl.isAdmin(accessControlState, caller)) { profile.ownerContact } else { existingAnimal.ownerContact };
          isVerified = profile.isVerified;
        };
        animals.add(animalId, safeProfile);
      };
      case (null) {
        Runtime.trap("Animal profile not found");
      };
    };
  };

  public shared ({ caller }) func sendMessage(conversationId : Principal, recipientId : Principal, content : Text, timestamp : Int) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can send messages");
    };
    if (not isUserVerified(caller)) {
      Runtime.trap("Unauthorized: Only verified users can contact animal owners");
    };
    if (not userExists(recipientId)) {
      Runtime.trap("Recipient user does not exist");
    };
    if (not isUserVerified(recipientId)) {
      Runtime.trap("Unauthorized: Can only message verified users");
    };
    
    // Validate conversation participants
    switch (conversationParticipants.get(conversationId)) {
      case (null) {
        // New conversation - caller must be one of the participants
        if (caller != recipientId) {
          conversationParticipants.add(conversationId, (caller, recipientId));
        } else {
          Runtime.trap("Cannot create conversation with yourself");
        };
      };
      case (?(user1, user2)) {
        // Existing conversation - validate caller is a participant
        if (caller != user1 and caller != user2) {
          Runtime.trap("Unauthorized: Not a participant in this conversation");
        };
        // Validate recipient is the other participant
        if (caller == user1 and recipientId != user2) {
          Runtime.trap("Unauthorized: Recipient is not part of this conversation");
        };
        if (caller == user2 and recipientId != user1) {
          Runtime.trap("Unauthorized: Recipient is not part of this conversation");
        };
      };
    };
    
    let message : ChatMessage = { sender = caller; content; timestamp };
    let currentMessages = switch (messages.get(conversationId)) {
      case (?existing) { existing };
      case (null) { List.empty<ChatMessage>() };
    };
    currentMessages.add(message);
    messages.add(conversationId, currentMessages);
  };

  public shared ({ caller }) func deleteAnimalProfile(animalId : Principal) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can delete animal profiles");
    };
    switch (animals.get(animalId)) {
      case (?animal) {
        if (animal.ownerContact != caller and not AccessControl.isAdmin(accessControlState, caller)) {
          Runtime.trap("Unauthorized: Can only delete your own animal profiles");
        };
        animals.remove(animalId);
      };
      case (null) {
        Runtime.trap("Animal profile not found");
      };
    };
  };

  public shared ({ caller }) func followUser(userToFollow : Principal) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can follow others");
    };
    if (caller == userToFollow) {
      Runtime.trap("Cannot follow yourself");
    };
    if (not userExists(userToFollow)) {
      Runtime.trap("User to follow does not exist");
    };
    if (not isProfileVisible(userToFollow, caller)) {
      Runtime.trap("Unauthorized: Cannot follow private profiles");
    };
    let followingList = switch (following.get(caller)) {
      case (?existing) { existing };
      case (null) { List.empty<Principal>() };
    };
    let alreadyFollowing = followingList.toArray().any(func(user) { user == userToFollow });
    if (alreadyFollowing) {
      Runtime.trap("Already following this user");
    };
    followingList.add(userToFollow);
    following.add(caller, followingList);
    let followersList = switch (followers.get(userToFollow)) {
      case (?existing) { existing };
      case (null) { List.empty<Principal>() };
    };
    followersList.add(caller);
    followers.add(userToFollow, followersList);
  };

  public shared ({ caller }) func unfollowUser(userToUnfollow : Principal) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can unfollow others");
    };
    if (caller == userToUnfollow) {
      Runtime.trap("Cannot unfollow yourself");
    };
    if (not userExists(userToUnfollow)) {
      Runtime.trap("User to unfollow does not exist");
    };
    let followingList = switch (following.get(caller)) {
      case (?existing) { existing };
      case (null) { List.empty<Principal>() };
    };
    if (followingList.isEmpty()) {
      Runtime.trap("Not following this user");
    };
    let filteredFollowing = followingList.filter(func(user) { user != userToUnfollow });
    following.add(caller, filteredFollowing);
    let followersList = switch (followers.get(userToUnfollow)) {
      case (?existing) { existing };
      case (null) { List.empty<Principal>() };
    };
    let filteredFollowers = followersList.filter(func(user) { user != caller });
    followers.add(userToUnfollow, filteredFollowers);
  };
};
