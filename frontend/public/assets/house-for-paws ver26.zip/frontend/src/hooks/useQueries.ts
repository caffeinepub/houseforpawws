import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { AnimalProfile, UserProfile, ChatMessage, UserSettings } from '../backend';
import { Principal } from '@dfinity/principal';
import { toast } from 'sonner';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useGetUserProfile(userId: Principal | null) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<UserProfile | null>({
    queryKey: ['userProfile', userId?.toString()],
    queryFn: async () => {
      if (!actor || !userId) return null;
      return actor.getUserProfile(userId);
    },
    enabled: !!actor && !actorFetching && !!userId,
  });
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      toast.success('Profile saved successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to save profile: ${error.message}`);
    },
  });
}

export function useGetCallerUserSettings() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<UserSettings | null>({
    queryKey: ['currentUserSettings'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserSettings();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useSaveCallerUserSettings() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (settings: UserSettings) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserSettings(settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserSettings'] });
      toast.success('Settings saved successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to save settings: ${error.message}`);
    },
  });
}

export function useGetAllAnimals() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<[Principal, AnimalProfile][]>({
    queryKey: ['animals'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllAnimals();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetAnimalsByCity(city: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<[Principal, AnimalProfile][]>({
    queryKey: ['animals', 'city', city],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAnimalsByCity(city);
    },
    enabled: !!actor && !actorFetching && !!city,
  });
}

export function useGetAnimalProfile(animalId: Principal | null) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<AnimalProfile>({
    queryKey: ['animal', animalId?.toString()],
    queryFn: async () => {
      if (!actor || !animalId) throw new Error('Actor or animalId not available');
      return actor.getAnimalProfile(animalId);
    },
    enabled: !!actor && !actorFetching && !!animalId,
  });
}

export function useCreateAnimalProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: AnimalProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createAnimalProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      toast.success('Animal profile created successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to create profile: ${error.message}`);
    },
  });
}

export function useUpdateAnimalProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ animalId, profile }: { animalId: Principal; profile: AnimalProfile }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateAnimalProfile(animalId, profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      toast.success('Animal profile updated successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update profile: ${error.message}`);
    },
  });
}

export function useDeleteAnimalProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (animalId: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deleteAnimalProfile(animalId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      toast.success('Animal profile deleted successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete profile: ${error.message}`);
    },
  });
}

export function useGetMessages(conversationId: Principal | null) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<ChatMessage[]>({
    queryKey: ['messages', conversationId?.toString()],
    queryFn: async () => {
      if (!actor || !conversationId) return [];
      return actor.getMessages(conversationId);
    },
    enabled: !!actor && !actorFetching && !!conversationId,
    refetchInterval: 3000,
  });
}

export function useSendMessage() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      conversationId,
      recipientId,
      content,
    }: {
      conversationId: Principal;
      recipientId: Principal;
      content: string;
    }) => {
      if (!actor) throw new Error('Actor not available');
      const timestamp = BigInt(Date.now() * 1_000_000);
      return actor.sendMessage(conversationId, recipientId, content, timestamp);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['messages', variables.conversationId.toString()] });
    },
    onError: (error: Error) => {
      toast.error(`Failed to send message: ${error.message}`);
    },
  });
}

export function useFollowUser() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (userToFollow: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.followUser(userToFollow);
    },
    onSuccess: (_, userToFollow) => {
      // Invalidate all follower/following queries to ensure UI updates
      queryClient.invalidateQueries({ queryKey: ['followers'] });
      queryClient.invalidateQueries({ queryKey: ['following'] });
      toast.success('Followed successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to follow: ${error.message}`);
    },
  });
}

export function useUnfollowUser() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (userToUnfollow: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.unfollowUser(userToUnfollow);
    },
    onSuccess: (_, userToUnfollow) => {
      // Invalidate all follower/following queries to ensure UI updates
      queryClient.invalidateQueries({ queryKey: ['followers'] });
      queryClient.invalidateQueries({ queryKey: ['following'] });
      toast.success('Unfollowed successfully!');
    },
    onError: (error: Error) => {
      toast.error(`Failed to unfollow: ${error.message}`);
    },
  });
}

export function useGetFollowers(userId: Principal | null) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Principal[]>({
    queryKey: ['followers', userId?.toString()],
    queryFn: async () => {
      if (!actor || !userId) return [];
      return actor.getFollowers(userId);
    },
    enabled: !!actor && !actorFetching && !!userId,
  });
}

export function useGetFollowing(userId: Principal | null) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Principal[]>({
    queryKey: ['following', userId?.toString()],
    queryFn: async () => {
      if (!actor || !userId) return [];
      return actor.getFollowing(userId);
    },
    enabled: !!actor && !actorFetching && !!userId,
  });
}

export function useSearchUserProfiles(searchTerm: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<[Principal, UserProfile][]>({
    queryKey: ['searchProfiles', searchTerm],
    queryFn: async () => {
      if (!actor || !searchTerm.trim()) return [];
      return actor.searchUserProfiles(searchTerm.trim());
    },
    enabled: !!actor && !actorFetching && !!searchTerm.trim(),
  });
}
