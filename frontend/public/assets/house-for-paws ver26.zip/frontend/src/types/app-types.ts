import type { Principal } from '@dfinity/principal';

// ExternalBlob type from blob storage
export interface ExternalBlob {
  getBytes(): Promise<Uint8Array>;
  getDirectURL(): string;
  withUploadProgress(onProgress: (percentage: number) => void): ExternalBlob;
}

export interface ExternalBlobStatic {
  fromURL(url: string): ExternalBlob;
  fromBytes(blob: Uint8Array): ExternalBlob;
}

declare const ExternalBlobConstructor: ExternalBlobStatic;
export { ExternalBlobConstructor as ExternalBlobClass };

export type UserRoleApp = { owner: null } | { adopter: null };

export interface NotificationPreferences {
  animalActivity: boolean;
  newMessages: boolean;
  appUpdates: boolean;
}

export type Theme = { light: null } | { pastel: null };

export type ProfileVisibility = { public_: null } | { private_: null };

export interface UserProfile {
  avatar: ExternalBlob | null;
  name: string;
  bio: string;
  city: string;
  role: UserRoleApp;
  isVerified: boolean;
}

export interface AnimalProfile {
  photo: ExternalBlob;
  name: string;
  age: bigint;
  bio: string;
  city: string;
  ownerContact: Principal;
  isVerified: boolean;
}

export interface UserSettings {
  profileVisibility: ProfileVisibility;
  notificationPreferences: NotificationPreferences;
  theme: Theme;
}

export interface ChatMessage {
  sender: Principal;
  content: string;
  timestamp: bigint;
  isRead: boolean;
  isDelivered: boolean;
}
