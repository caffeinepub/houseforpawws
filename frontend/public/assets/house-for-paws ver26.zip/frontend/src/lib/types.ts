// Helper type utilities for the application
import type { UserRoleApp, Theme, ProfileVisibility } from '../types/app-types';

export type UserRoleType = 'owner' | 'adopter';

export type ThemeType = 'light' | 'pastel';

export type ProfileVisibilityType = 'public' | 'private';

// Convert backend variant types to frontend string types
export function userRoleToString(role: UserRoleApp): UserRoleType {
  if (typeof role === 'object' && role !== null) {
    if (Object.prototype.hasOwnProperty.call(role, 'owner')) return 'owner';
    if (Object.prototype.hasOwnProperty.call(role, 'adopter')) return 'adopter';
  }
  return 'adopter';
}

export function stringToUserRole(role: UserRoleType): UserRoleApp {
  return role === 'owner' ? { owner: null } : { adopter: null };
}

export function themeToString(theme: Theme): ThemeType {
  if (typeof theme === 'object' && theme !== null) {
    if (Object.prototype.hasOwnProperty.call(theme, 'light')) return 'light';
    if (Object.prototype.hasOwnProperty.call(theme, 'pastel')) return 'pastel';
  }
  return 'pastel';
}

export function stringToTheme(theme: ThemeType): Theme {
  return theme === 'light' ? { light: null } : { pastel: null };
}

export function visibilityToString(visibility: ProfileVisibility): ProfileVisibilityType {
  if (typeof visibility === 'object' && visibility !== null) {
    if (Object.prototype.hasOwnProperty.call(visibility, 'public_')) return 'public';
    if (Object.prototype.hasOwnProperty.call(visibility, 'private_')) return 'private';
  }
  return 'public';
}

export function stringToVisibility(visibility: ProfileVisibilityType): ProfileVisibility {
  return visibility === 'public' ? { public_: null } : { private_: null };
}
