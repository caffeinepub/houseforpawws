import { useState, useEffect } from 'react';
import { Principal } from '@dfinity/principal';
import type { AnimalProfile } from '../backend';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetCallerUserProfile, useDeleteAnimalProfile } from '../hooks/useQueries';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar, Mail, Trash2, Share2 } from 'lucide-react';
import ContactDialog from './ContactDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';

interface AnimalDetailDialogProps {
  animalId: Principal;
  animal: AnimalProfile;
  open: boolean;
  onClose: () => void;
}

export default function AnimalDetailDialog({
  animalId,
  animal,
  open,
  onClose,
}: AnimalDetailDialogProps) {
  const { identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const { mutate: deleteAnimal, isPending: isDeleting } = useDeleteAnimalProfile();
  const [imageUrl, setImageUrl] = useState<string>('');
  const [showContactDialog, setShowContactDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const isAuthenticated = !!identity;
  const isOwner = identity?.getPrincipal().toString() === animal.ownerContact.toString();
  const canContact = isAuthenticated && userProfile?.isVerified && !isOwner;

  useEffect(() => {
    const loadImage = async () => {
      try {
        const url = animal.photo.getDirectURL();
        setImageUrl(url);
      } catch (error) {
        console.error('Failed to load image:', error);
      }
    };
    loadImage();
  }, [animal.photo]);

  const handleDelete = () => {
    deleteAnimal(animalId, {
      onSuccess: () => {
        setShowDeleteDialog(false);
        onClose();
      },
    });
  };

  const handleShare = () => {
    const shareUrl = `${window.location.origin}/profile/${animal.ownerContact.toString()}`;
    const shareText = `Check out ${animal.name}, a ${animal.age}-year-old pet looking for a home in ${animal.city}!`;
    
    if (navigator.share) {
      navigator.share({
        title: `${animal.name} - House for Paws`,
        text: shareText,
        url: shareUrl,
      }).catch(() => {
        // User cancelled or error occurred
      });
    } else {
      navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      toast.success('Link copied to clipboard!');
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{animal.name}</DialogTitle>
            <DialogDescription>
              {animal.isVerified && (
                <Badge className="bg-primary text-primary-foreground rounded-full">✓ Verified Listing</Badge>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="relative h-96 rounded-xl overflow-hidden bg-muted">
              {imageUrl ? (
                <img src={imageUrl} alt={animal.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="h-5 w-5" />
                <span>
                  <strong className="text-foreground">Age:</strong> {Number(animal.age)} years
                </span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-5 w-5" />
                <span>
                  <strong className="text-foreground">Location:</strong> {animal.city}
                </span>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">About {animal.name}</h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{animal.bio}</p>
            </div>

            <div className="flex gap-3 pt-4 border-t">
              {canContact && (
                <Button onClick={() => setShowContactDialog(true)} className="flex-1 gap-2 rounded-full">
                  <Mail className="h-4 w-4" />
                  Contact Owner
                </Button>
              )}
              <Button onClick={handleShare} variant="outline" className="gap-2 rounded-full">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              {!isAuthenticated && (
                <p className="text-sm text-muted-foreground flex-1">
                  Please log in to contact the owner
                </p>
              )}
              {isAuthenticated && !userProfile?.isVerified && !isOwner && (
                <p className="text-sm text-muted-foreground flex-1">
                  Only verified users can contact owners
                </p>
              )}
              {isOwner && (
                <Button
                  variant="destructive"
                  onClick={() => setShowDeleteDialog(true)}
                  disabled={isDeleting}
                  className="gap-2 rounded-full"
                >
                  <Trash2 className="h-4 w-4" />
                  {isDeleting ? 'Deleting...' : 'Delete Listing'}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {showContactDialog && (
        <ContactDialog
          animalId={animalId}
          animalName={animal.name}
          ownerId={animal.ownerContact}
          open={showContactDialog}
          onClose={() => setShowContactDialog(false)}
        />
      )}

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Animal Listing</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {animal.name}'s listing? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90 rounded-full">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
