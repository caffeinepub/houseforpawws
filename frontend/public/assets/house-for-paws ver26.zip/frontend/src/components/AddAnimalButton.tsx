import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import AddAnimalDialog from './AddAnimalDialog';

export default function AddAnimalButton() {
  const [showDialog, setShowDialog] = useState(false);

  return (
    <>
      <Button onClick={() => setShowDialog(true)} className="gap-2 rounded-full shadow-lg">
        <Plus className="h-5 w-5" />
        Add Pet
      </Button>
      <AddAnimalDialog open={showDialog} onClose={() => setShowDialog(false)} />
    </>
  );
}
