export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10 border-b border-border/40">
      <div className="container mx-auto px-4 py-16 md:py-20">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Find Your Perfect{' '}
              <span className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                Furry Friend
              </span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-xl">
              Connect with animals in need of loving homes. Follow friends, share adorable pets, and
              make a difference in an animal's life today.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-full border border-border shadow-sm">
                <img src="/assets/generated/paw-icon-transparent.dim_64x64.png" alt="" className="h-6 w-6" />
                <span className="text-sm font-medium">Verified Listings</span>
              </div>
              <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-full border border-border shadow-sm">
                <img src="/assets/generated/location-home-transparent.dim_64x64.png" alt="" className="h-6 w-6" />
                <span className="text-sm font-medium">Local Search</span>
              </div>
              <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-full border border-border shadow-sm">
                <img src="/assets/generated/adoption-heart-transparent.dim_64x64.png" alt="" className="h-6 w-6" />
                <span className="text-sm font-medium">Social Feed</span>
              </div>
            </div>
          </div>
          <div className="relative h-[300px] md:h-[400px] rounded-3xl overflow-hidden shadow-2xl">
            <div className="absolute inset-0 grid grid-cols-2 gap-2 p-2">
              <img
                src="/assets/generated/hero-dog.dim_800x600.jpg"
                alt="Happy dog"
                className="w-full h-full object-cover rounded-2xl"
              />
              <img
                src="/assets/generated/hero-cat.dim_800x600.jpg"
                alt="Cute cat"
                className="w-full h-full object-cover rounded-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
