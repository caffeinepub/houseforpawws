import { Heart } from 'lucide-react';
import { useState } from 'react';
import TOSModal from './TOSModal';

export default function Footer() {
  const [showTOS, setShowTOS] = useState(false);

  return (
    <>
      <footer className="border-t border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col items-center justify-center gap-2 text-sm text-muted-foreground">
            <p className="flex items-center gap-1">
              © 2025. Built with <Heart className="h-4 w-4 text-primary fill-primary" /> using{' '}
              <a
                href="https://caffeine.ai"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline font-medium"
              >
                caffeine.ai
              </a>
            </p>
            <button
              onClick={() => setShowTOS(true)}
              className="text-primary hover:underline text-xs"
            >
              Terms of Service
            </button>
          </div>
        </div>
      </footer>

      <TOSModal open={showTOS} onClose={() => setShowTOS(false)} />
    </>
  );
}
