import { Principal } from '@dfinity/principal';
import type { AnimalProfile } from '../backend';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Calendar, Share2 } from 'lucide-react';
import { toast } from 'sonner';

interface AnimalCardProps {
  animalId: Principal;
  animal: AnimalProfile;
  onClick: () => void;
}

export default function AnimalCard({ animalId, animal, onClick }: AnimalCardProps) {
  const imageUrl = animal.photo.getDirectURL();

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareUrl = `${window.location.origin}/profile/${animal.ownerContact.toString()}`;
    const shareText = `Check out ${animal.name}, a ${animal.age}-year-old pet looking for a home in ${animal.city}!`;
    
    if (navigator.share) {
      navigator.share({
        title: `${animal.name} - House for Paws`,
        text: shareText,
        url: shareUrl,
      }).catch(() => {
        // User cancelled or error occurred
      });
    } else {
      navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      toast.success('Link copied to clipboard!');
    }
  };

  return (
    <Card
      className="overflow-hidden cursor-pointer transition-all hover:shadow-lg hover:-translate-y-1 border-2 rounded-3xl group"
      onClick={onClick}
    >
      <div className="aspect-square relative overflow-hidden bg-muted">
        <img
          src={imageUrl}
          alt={animal.name}
          className="w-full h-full object-cover"
        />
        {animal.isVerified && (
          <Badge className="absolute top-3 right-3 bg-primary/90 backdrop-blur rounded-full">
            ✓ Verified
          </Badge>
        )}
        <Button
          size="icon"
          variant="secondary"
          className="absolute bottom-3 right-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
          onClick={handleShare}
        >
          <Share2 className="h-4 w-4" />
        </Button>
      </div>
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between">
          <h3 className="text-xl font-bold text-foreground">{animal.name}</h3>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>{animal.age.toString()}y</span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>{animal.city}</span>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">{animal.bio}</p>
      </CardContent>
    </Card>
  );
}
