import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Heart } from 'lucide-react';

interface TOSModalProps {
  open: boolean;
  onClose: () => void;
}

export default function TOSModal({ open, onClose }: TOSModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Heart className="h-6 w-6 text-primary fill-primary" />
            Terms of Service
          </DialogTitle>
          <DialogDescription>
            Please read our terms of service carefully
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4 text-sm">
            <section>
              <h3 className="font-semibold text-base mb-2">1. Acceptance of Terms</h3>
              <p className="text-muted-foreground">
                By accessing and using House for Paws, you accept and agree to be bound by the terms
                and provision of this agreement. If you do not agree to these terms, please do not
                use this service.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">2. Use of Service</h3>
              <p className="text-muted-foreground">
                House for Paws is a platform designed to connect animals in need of homes with
                potential adopters. Users must be at least 18 years old to use this service. You
                agree to use the service only for lawful purposes and in accordance with these Terms.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">3. User Accounts and Verification</h3>
              <p className="text-muted-foreground">
                Users must provide accurate and complete information when creating profiles. Verified
                status is granted to authorized shelters and organizations. Misrepresentation of
                verification status is strictly prohibited and may result in account termination.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">4. Animal Listings</h3>
              <p className="text-muted-foreground">
                Users posting animals for adoption must ensure all information provided is accurate
                and truthful. You are responsible for the welfare of any animals you list. House for
                Paws is not responsible for the actual adoption process or the welfare of animals
                after adoption.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">5. User Conduct</h3>
              <p className="text-muted-foreground">
                Users agree not to post content that is illegal, harmful, threatening, abusive,
                harassing, defamatory, or otherwise objectionable. Users must not impersonate others
                or misrepresent their affiliation with any person or organization.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">6. Privacy and Data</h3>
              <p className="text-muted-foreground">
                We respect your privacy and handle your data in accordance with applicable laws. By
                using House for Paws, you consent to the collection and use of information as
                outlined in our Privacy Policy. User data is stored on the Internet Computer
                blockchain.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">7. Content Ownership</h3>
              <p className="text-muted-foreground">
                Users retain ownership of content they post but grant House for Paws a license to
                use, display, and distribute such content on the platform. You represent that you
                have the right to post any content you upload.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">8. Messaging and Communication</h3>
              <p className="text-muted-foreground">
                The messaging feature is provided for adoption-related communication only. Users must
                communicate respectfully and professionally. Harassment or inappropriate behavior may
                result in account suspension.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">9. Disclaimer of Warranties</h3>
              <p className="text-muted-foreground">
                House for Paws is provided "as is" without warranties of any kind. We do not
                guarantee the accuracy, completeness, or reliability of any content on the platform.
                We are not responsible for any interactions between users or adoption outcomes.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">10. Limitation of Liability</h3>
              <p className="text-muted-foreground">
                House for Paws and its operators shall not be liable for any indirect, incidental,
                special, consequential, or punitive damages resulting from your use of the service.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">11. Modifications to Terms</h3>
              <p className="text-muted-foreground">
                We reserve the right to modify these terms at any time. Continued use of the service
                after changes constitutes acceptance of the modified terms.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">12. Termination</h3>
              <p className="text-muted-foreground">
                We reserve the right to terminate or suspend access to the service immediately,
                without prior notice, for any reason, including breach of these Terms.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">13. Contact Information</h3>
              <p className="text-muted-foreground">
                For questions about these Terms of Service, please contact us through the platform's
                messaging system or visit our website.
              </p>
            </section>

            <div className="pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground italic">
                Last updated: January 28, 2026
              </p>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
