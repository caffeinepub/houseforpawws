import { useState, useEffect } from 'react';
import { useSaveCallerUserProfile, useGetCallerUserProfile } from '../hooks/useQueries';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, X } from 'lucide-react';
import type { UserProfile } from '../backend';
import { UserRole, ExternalBlob } from '../backend';

interface ProfileEditDialogProps {
  open: boolean;
  onClose: () => void;
}

export default function ProfileEditDialog({ open, onClose }: ProfileEditDialogProps) {
  const { data: currentProfile } = useGetCallerUserProfile();
  const [bio, setBio] = useState('');
  const [city, setCity] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.adopter);
  const [isVerified, setIsVerified] = useState(false);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string>('');
  const [keepExistingAvatar, setKeepExistingAvatar] = useState(true);
  const { mutate: saveProfile, isPending } = useSaveCallerUserProfile();

  useEffect(() => {
    if (currentProfile) {
      setBio(currentProfile.bio);
      setCity(currentProfile.city);
      setRole(currentProfile.role);
      setIsVerified(currentProfile.isVerified);
      if (currentProfile.avatar) {
        setAvatarPreview(currentProfile.avatar.getDirectURL());
        setKeepExistingAvatar(true);
      }
    }
  }, [currentProfile]);

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAvatarFile(file);
      setKeepExistingAvatar(false);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bio.trim() || !city.trim()) return;

    try {
      let avatarBlob: ExternalBlob | undefined;

      if (avatarFile) {
        const arrayBuffer = await avatarFile.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);
        avatarBlob = ExternalBlob.fromBytes(uint8Array);
      } else if (keepExistingAvatar && currentProfile?.avatar) {
        avatarBlob = currentProfile.avatar;
      }

      const profile: UserProfile = {
        bio: bio.trim(),
        city: city.trim(),
        role,
        isVerified,
        avatar: avatarBlob,
      };

      saveProfile(profile, {
        onSuccess: () => {
          onClose();
        },
      });
    } catch (error) {
      console.error('Failed to save profile:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
          <DialogDescription>
            Update your profile information and preferences.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="avatar">Profile Picture</Label>
            <div className="border-2 border-dashed border-border rounded-2xl p-4">
              {avatarPreview ? (
                <div className="relative">
                  <img
                    src={avatarPreview}
                    alt="Avatar preview"
                    className="w-32 h-32 object-cover rounded-full mx-auto"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute top-0 right-1/2 translate-x-16 rounded-full"
                    onClick={() => {
                      setAvatarFile(null);
                      setAvatarPreview('');
                      setKeepExistingAvatar(false);
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center h-32 cursor-pointer">
                  <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                  <span className="text-sm text-muted-foreground">Upload avatar (optional)</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio *</Label>
            <Textarea
              id="bio"
              placeholder="Tell us about yourself..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="rounded-2xl"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="city">City *</Label>
            <Input
              id="city"
              placeholder="e.g., San Francisco"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="rounded-2xl"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">I am a *</Label>
            <Select value={role} onValueChange={(value) => setRole(value as UserRole)}>
              <SelectTrigger className="rounded-2xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={UserRole.adopter}>Adopter (looking for pets)</SelectItem>
                <SelectItem value={UserRole.owner}>Owner (rehoming pets)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox id="verified" checked={isVerified} onCheckedChange={(checked) => setIsVerified(checked === true)} />
            <Label htmlFor="verified" className="text-sm font-normal cursor-pointer">
              I am a verified shelter or authorized organization
            </Label>
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 rounded-full">
              Cancel
            </Button>
            <Button type="submit" className="flex-1 rounded-full" disabled={isPending || !bio.trim() || !city.trim()}>
              {isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
