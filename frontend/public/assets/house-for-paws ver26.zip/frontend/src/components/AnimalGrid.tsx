import { useState, useMemo } from 'react';
import { Principal } from '@dfinity/principal';
import type { AnimalProfile } from '../backend';
import AnimalCard from './AnimalCard';
import AnimalDetailDialog from './AnimalDetailDialog';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface AnimalGridProps {
  animals: [Principal, AnimalProfile][];
  isLoading: boolean;
}

export default function AnimalGrid({ animals, isLoading }: AnimalGridProps) {
  const [selectedAnimal, setSelectedAnimal] = useState<[Principal, AnimalProfile] | null>(null);
  const [searchCity, setSearchCity] = useState('');

  const filteredAnimals = useMemo(() => {
    if (!searchCity.trim()) return animals;
    return animals.filter(([_, animal]) =>
      animal.city.toLowerCase().includes(searchCity.toLowerCase())
    );
  }, [animals, searchCity]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="max-w-md">
          <Skeleton className="h-10 w-full" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="h-64 w-full rounded-xl" />
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!animals || animals.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground text-lg">No animals available for adoption yet.</p>
        <p className="text-sm text-muted-foreground mt-2">Check back soon or be the first to post!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by city..."
            value={searchCity}
            onChange={(e) => setSearchCity(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {filteredAnimals.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-muted-foreground">No animals found in "{searchCity}"</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAnimals.map((animal) => (
            <AnimalCard
              key={animal[0].toString()}
              animalId={animal[0]}
              animal={animal[1]}
              onClick={() => setSelectedAnimal(animal)}
            />
          ))}
        </div>
      )}

      {selectedAnimal && (
        <AnimalDetailDialog
          animalId={selectedAnimal[0]}
          animal={selectedAnimal[1]}
          open={!!selectedAnimal}
          onClose={() => setSelectedAnimal(null)}
        />
      )}
    </div>
  );
}
