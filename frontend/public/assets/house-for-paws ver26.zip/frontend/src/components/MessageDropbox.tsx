import { useState, useEffect } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetConversations, useGetUserProfile } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import ChatBox from './ChatBox';
import { Principal } from '@dfinity/principal';

export default function MessageDropbox() {
  const { identity } = useInternetIdentity();
  const [open, setOpen] = useState(false);
  const [selectedChat, setSelectedChat] = useState<{
    conversationId: Principal;
    recipientId: Principal;
    recipientName: string;
  } | null>(null);

  const { data: conversations = [], refetch } = useGetConversations();

  // Refetch conversations when the sheet opens to ensure fresh data
  useEffect(() => {
    if (open) {
      refetch();
    }
  }, [open, refetch]);

  // Auto-refresh conversations every 5 seconds when sheet is open
  useEffect(() => {
    if (!open) return;
    
    const interval = setInterval(() => {
      refetch();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [open, refetch]);

  const getInitials = (name: string) => {
    if (!name || !name.trim()) return 'U';
    const words = name.trim().split(' ');
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  if (!identity) return null;

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button
            size="icon"
            className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg hover:shadow-xl transition-all z-40 bg-gradient-to-br from-primary to-secondary"
          >
            <img
              src="/assets/generated/message-dropbox-icon-transparent.dim_32x32.png"
              alt="Messages"
              className="h-7 w-7"
            />
            {conversations.length > 0 && (
              <Badge
                variant="destructive"
                className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
              >
                {conversations.length}
              </Badge>
            )}
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="w-full sm:w-96 rounded-l-3xl">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-primary" />
              Messages
            </SheetTitle>
          </SheetHeader>
          <ScrollArea className="h-[calc(100vh-8rem)] mt-6">
            {conversations.length > 0 ? (
              <div className="space-y-2">
                {conversations.map(([conversationId, participants]) => {
                  const currentUserId = identity.getPrincipal().toString();
                  const otherUserId = participants[0].toString() === currentUserId 
                    ? participants[1].toString() 
                    : participants[0].toString();
                  
                  return (
                    <ConversationItem
                      key={conversationId.toString()}
                      conversationId={conversationId}
                      userId={otherUserId}
                      onSelect={(recipientId, recipientName) => {
                        setSelectedChat({ conversationId, recipientId, recipientName });
                        setOpen(false);
                      }}
                      getInitials={getInitials}
                    />
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <MessageCircle className="h-12 w-12 text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground">No conversations yet</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Start chatting with pet owners!
                </p>
              </div>
            )}
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {selectedChat && (
        <Dialog open={!!selectedChat} onOpenChange={() => setSelectedChat(null)}>
          <DialogContent className="max-w-2xl rounded-3xl">
            <DialogHeader>
              <DialogTitle className="sr-only">Chat with {selectedChat.recipientName}</DialogTitle>
            </DialogHeader>
            <ChatBox
              conversationId={selectedChat.conversationId}
              recipientId={selectedChat.recipientId}
              recipientName={selectedChat.recipientName}
            />
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

interface ConversationItemProps {
  conversationId: Principal;
  userId: string;
  onSelect: (recipientId: Principal, recipientName: string) => void;
  getInitials: (name: string) => string;
}

function ConversationItem({ conversationId, userId, onSelect, getInitials }: ConversationItemProps) {
  const userPrincipal = Principal.fromText(userId);
  const { data: profile } = useGetUserProfile(userPrincipal);

  if (!profile) return null;

  return (
    <button
      onClick={() => onSelect(userPrincipal, profile.name || 'User')}
      className="w-full flex items-center gap-3 p-3 rounded-2xl hover:bg-accent/50 transition-colors text-left"
    >
      <Avatar className="h-12 w-12">
        {profile.avatar && (
          <AvatarImage src={profile.avatar.getDirectURL()} alt={profile.name} />
        )}
        <AvatarFallback className="bg-primary text-primary-foreground">
          {getInitials(profile.name || 'User')}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">{profile.name || 'Anonymous User'}</p>
        <p className="text-sm text-muted-foreground truncate">{profile.city}</p>
      </div>
    </button>
  );
}
