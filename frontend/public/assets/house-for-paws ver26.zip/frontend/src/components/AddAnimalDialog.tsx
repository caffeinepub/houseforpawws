import { useState } from 'react';
import { useCreateAnimalProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Upload, X } from 'lucide-react';
import type { AnimalProfile } from '../backend';
import { ExternalBlob } from '../backend';

interface AddAnimalDialogProps {
  open: boolean;
  onClose: () => void;
}

export default function AddAnimalDialog({ open, onClose }: AddAnimalDialogProps) {
  const { identity } = useInternetIdentity();
  const { mutate: createAnimal, isPending } = useCreateAnimalProfile();
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [bio, setBio] = useState('');
  const [city, setCity] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !age || !bio.trim() || !city.trim() || !imageFile || !identity) return;

    try {
      const arrayBuffer = await imageFile.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      const photoBlob = ExternalBlob.fromBytes(uint8Array).withUploadProgress((percentage) => {
        setUploadProgress(percentage);
      });

      const profile: AnimalProfile = {
        name: name.trim(),
        age: BigInt(parseInt(age)),
        bio: bio.trim(),
        city: city.trim(),
        ownerContact: identity.getPrincipal(),
        isVerified,
        photo: photoBlob,
      };

      createAnimal(profile, {
        onSuccess: () => {
          setName('');
          setAge('');
          setBio('');
          setCity('');
          setIsVerified(false);
          setImageFile(null);
          setImagePreview('');
          setUploadProgress(0);
          onClose();
        },
      });
    } catch (error) {
      console.error('Failed to create animal profile:', error);
    }
  };

  const handleClose = () => {
    if (!isPending) {
      setName('');
      setAge('');
      setBio('');
      setCity('');
      setIsVerified(false);
      setImageFile(null);
      setImagePreview('');
      setUploadProgress(0);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Animal for Adoption</DialogTitle>
          <DialogDescription>
            Fill in the details to create a new animal listing. All fields are required.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="photo">Photo *</Label>
            <div className="border-2 border-dashed border-border rounded-lg p-4">
              {imagePreview ? (
                <div className="relative">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full h-64 object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2"
                    onClick={() => {
                      setImageFile(null);
                      setImagePreview('');
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center h-64 cursor-pointer">
                  <Upload className="h-12 w-12 text-muted-foreground mb-2" />
                  <span className="text-sm text-muted-foreground">Click to upload photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>
            {uploadProgress > 0 && uploadProgress < 100 && (
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                placeholder="e.g., Max"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="age">Age (years) *</Label>
              <Input
                id="age"
                type="number"
                min="0"
                placeholder="e.g., 3"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="city">City *</Label>
            <Input
              id="city"
              placeholder="e.g., San Francisco"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio *</Label>
            <Textarea
              id="bio"
              placeholder="Tell us about this animal's personality, needs, and why they're looking for a home..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="min-h-[120px]"
              required
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="verified"
              checked={isVerified}
              onCheckedChange={(checked) => setIsVerified(checked === true)}
            />
            <Label htmlFor="verified" className="text-sm font-normal cursor-pointer">
              This is a verified listing (shelter or authorized organization)
            </Label>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} disabled={isPending} className="flex-1">
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isPending || !name.trim() || !age || !bio.trim() || !city.trim() || !imageFile}
              className="flex-1"
            >
              {isPending ? 'Creating...' : 'Create Listing'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
