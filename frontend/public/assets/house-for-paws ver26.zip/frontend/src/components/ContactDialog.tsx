import { useState } from 'react';
import { Principal } from '@dfinity/principal';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import ChatBox from './ChatBox';

interface ContactDialogProps {
  animalId: Principal;
  animalName: string;
  ownerId: Principal;
  open: boolean;
  onClose: () => void;
}

export default function ContactDialog({
  animalId,
  animalName,
  ownerId,
  open,
  onClose,
}: ContactDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0 gap-0">
        <DialogHeader className="p-6 pb-4">
          <DialogTitle>Contact about {animalName}</DialogTitle>
          <DialogDescription>
            Chat with the owner to express your interest in adopting {animalName}.
          </DialogDescription>
        </DialogHeader>
        <div className="px-6 pb-6">
          <ChatBox
            conversationId={animalId}
            recipientId={ownerId}
            recipientName="Owner"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
