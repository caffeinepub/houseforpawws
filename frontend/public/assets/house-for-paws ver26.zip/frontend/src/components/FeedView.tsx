import { useState } from 'react';
import { Principal } from '@dfinity/principal';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetCallerUserProfile, useGetAllAnimals, useGetFollowing } from '../hooks/useQueries';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import AnimalGrid from './AnimalGrid';
import AddAnimalButton from './AddAnimalButton';
import { Heart, Grid3x3, Users } from 'lucide-react';

export default function FeedView() {
  const { identity } = useInternetIdentity();
  const isAuthenticated = !!identity;
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: animals, isLoading: animalsLoading } = useGetAllAnimals();
  const { data: followingList = [] } = useGetFollowing(
    isAuthenticated ? identity.getPrincipal() : null
  );

  // Filter animals from users that the current user follows
  const followingAnimals = animals?.filter(([animalId, animal]) => {
    return followingList.some(
      (followedUser) => followedUser.toString() === animal.ownerContact.toString()
    );
  }) || [];

  return (
    <section className="container mx-auto px-4 py-12">
      <Tabs defaultValue="all" className="w-full">
        <div className="flex items-center justify-between mb-8">
          <TabsList className="rounded-full bg-muted/50">
            <TabsTrigger value="all" className="rounded-full gap-2">
              <Grid3x3 className="h-4 w-4" />
              All Pets
            </TabsTrigger>
            <TabsTrigger value="following" className="rounded-full gap-2" disabled={!isAuthenticated}>
              <Heart className="h-4 w-4" />
              Following
            </TabsTrigger>
          </TabsList>
          {isAuthenticated && userProfile?.isVerified && <AddAnimalButton />}
        </div>

        <TabsContent value="all" className="mt-0">
          <div className="mb-6">
            <h2 className="text-3xl font-bold text-foreground mb-2">
              Animals Looking for Homes
            </h2>
            <p className="text-muted-foreground">
              Browse all available pets and find your perfect companion
            </p>
          </div>
          <AnimalGrid animals={animals || []} isLoading={animalsLoading} />
        </TabsContent>

        <TabsContent value="following" className="mt-0">
          <div className="mb-6">
            <h2 className="text-3xl font-bold text-foreground mb-2">
              Posts from People You Follow
            </h2>
            <p className="text-muted-foreground">
              See the latest pets shared by your connections
            </p>
          </div>
          {followingList.length === 0 ? (
            <Card className="rounded-3xl p-12 text-center">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground text-lg mb-2">You're not following anyone yet</p>
              <p className="text-sm text-muted-foreground">
                Follow other users to see their pet posts in your feed
              </p>
            </Card>
          ) : followingAnimals.length === 0 ? (
            <Card className="rounded-3xl p-12 text-center">
              <Heart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground text-lg mb-2">No posts yet</p>
              <p className="text-sm text-muted-foreground">
                The people you follow haven't posted any pets yet
              </p>
            </Card>
          ) : (
            <AnimalGrid animals={followingAnimals} isLoading={animalsLoading} />
          )}
        </TabsContent>
      </Tabs>
    </section>
  );
}
