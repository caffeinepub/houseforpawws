import { useState } from 'react';
import { useSearchUserProfiles } from '../hooks/useQueries';
import { useNavigate } from '@tanstack/react-router';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Search, MapPin, CheckCircle, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SearchProfilesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const { data: results = [], isLoading } = useSearchUserProfiles(searchTerm);

  const getInitials = (bio: string) => {
    const words = bio.trim().split(' ');
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return bio.slice(0, 2).toUpperCase();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => navigate({ to: '/' })}
        className="mb-4 rounded-full gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </Button>

      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Search Profiles
          </h1>
          <p className="text-muted-foreground">
            Find other pet lovers, adopters, and shelters
          </p>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search by name, city, or role..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 h-14 rounded-full text-lg border-2"
          />
        </div>

        {isLoading && searchTerm && (
          <div className="flex items-center justify-center py-12">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          </div>
        )}

        {!searchTerm && (
          <Card className="rounded-3xl border-2 p-12 text-center">
            <img
              src="/assets/generated/search-icon-transparent.dim_64x64.png"
              alt="Search"
              className="h-16 w-16 mx-auto mb-4 opacity-50"
            />
            <p className="text-muted-foreground">
              Start typing to search for profiles
            </p>
          </Card>
        )}

        {searchTerm && !isLoading && results.length === 0 && (
          <Card className="rounded-3xl border-2 p-12 text-center">
            <p className="text-muted-foreground">
              No profiles found matching "{searchTerm}"
            </p>
          </Card>
        )}

        {results.length > 0 && (
          <div className="grid gap-4 md:grid-cols-2">
            {results.map(([userId, profile]) => (
              <Card
                key={userId.toString()}
                className="rounded-3xl border-2 hover:shadow-lg transition-all cursor-pointer overflow-hidden"
                onClick={() =>
                  navigate({ to: '/profile/$userId', params: { userId: userId.toString() } })
                }
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-16 w-16 border-2 border-primary/20">
                      {profile.avatar && (
                        <AvatarImage src={profile.avatar.getDirectURL()} alt="Profile" />
                      )}
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials(profile.bio || 'User')}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg truncate">
                          {profile.bio || 'Anonymous User'}
                        </h3>
                        {profile.isVerified && (
                          <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <MapPin className="h-3 w-3" />
                        <span>{profile.city}</span>
                      </div>

                      <Badge variant="secondary" className="capitalize rounded-full">
                        {profile.role}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
