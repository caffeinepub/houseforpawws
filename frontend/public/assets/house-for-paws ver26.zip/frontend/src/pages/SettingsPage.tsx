import { useState, useEffect } from 'react';
import { useGetCallerUserSettings, useSaveCallerUserSettings } from '../hooks/useQueries';
import { useNavigate } from '@tanstack/react-router';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Settings as SettingsIcon, Save, FileText } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { UserSettings, Variant_public_private, Variant_light_pastel } from '../backend';
import TOSModal from '../components/TOSModal';

export default function SettingsPage() {
  const navigate = useNavigate();
  const { data: settings, isLoading } = useGetCallerUserSettings();
  const { mutate: saveSettings, isPending } = useSaveCallerUserSettings();
  const [showTOS, setShowTOS] = useState(false);

  const [profileVisibility, setProfileVisibility] = useState<Variant_public_private>(Variant_public_private.public_);
  const [notificationPreferences, setNotificationPreferences] = useState('');
  const [theme, setTheme] = useState<Variant_light_pastel>(Variant_light_pastel.light);

  useEffect(() => {
    if (settings) {
      setProfileVisibility(settings.profileVisibility);
      setNotificationPreferences(settings.notificationPreferences);
      setTheme(settings.theme);
    }
  }, [settings]);

  const handleSave = () => {
    const newSettings: UserSettings = {
      profileVisibility,
      notificationPreferences,
      theme,
    };
    saveSettings(newSettings);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate({ to: '/' })}
          className="mb-4 rounded-full gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>

        <div className="max-w-2xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <img
                src="/assets/generated/settings-icon-transparent.dim_64x64.png"
                alt="Settings"
                className="h-12 w-12"
              />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Settings
              </h1>
            </div>
            <p className="text-muted-foreground">
              Manage your preferences and privacy settings
            </p>
          </div>

          <Card className="rounded-3xl border-2 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <SettingsIcon className="h-5 w-5 text-primary" />
                Profile Settings
              </CardTitle>
              <CardDescription>
                Control who can see your profile and how you appear to others
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="visibility" className="text-base font-semibold">
                  Profile Visibility
                </Label>
                <div className="flex items-center justify-between p-4 rounded-2xl bg-muted/50">
                  <div>
                    <p className="font-medium">Public Profile</p>
                    <p className="text-sm text-muted-foreground">
                      Anyone can view your profile
                    </p>
                  </div>
                  <Switch
                    id="visibility"
                    checked={profileVisibility === Variant_public_private.public_}
                    onCheckedChange={(checked) =>
                      setProfileVisibility(checked ? Variant_public_private.public_ : Variant_public_private.private_)
                    }
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="theme" className="text-base font-semibold">
                  App Theme
                </Label>
                <RadioGroup value={theme} onValueChange={(value) => setTheme(value as Variant_light_pastel)}>
                  <div className="flex items-center space-x-2 p-4 rounded-2xl bg-muted/50">
                    <RadioGroupItem value={Variant_light_pastel.light} id="light" />
                    <Label htmlFor="light" className="flex-1 cursor-pointer">
                      <p className="font-medium">Light Theme</p>
                      <p className="text-sm text-muted-foreground">
                        Clean and bright interface
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 p-4 rounded-2xl bg-muted/50">
                    <RadioGroupItem value={Variant_light_pastel.pastel} id="pastel" />
                    <Label htmlFor="pastel" className="flex-1 cursor-pointer">
                      <p className="font-medium">Pastel Theme</p>
                      <p className="text-sm text-muted-foreground">
                        Soft and cute colors
                      </p>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-3">
                <Label htmlFor="notifications" className="text-base font-semibold">
                  Notification Preferences
                </Label>
                <p className="text-sm text-muted-foreground">
                  Note: Email notifications are not yet implemented. These preferences will be used in future updates.
                </p>
                <Textarea
                  id="notifications"
                  placeholder="e.g., I want to receive notifications about new messages and adoption inquiries"
                  value={notificationPreferences}
                  onChange={(e) => setNotificationPreferences(e.target.value)}
                  className="rounded-2xl min-h-[100px]"
                />
              </div>

              <Button
                onClick={handleSave}
                disabled={isPending}
                className="w-full rounded-full gap-2"
              >
                {isPending ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Save Settings
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Legal
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button
                variant="outline"
                onClick={() => setShowTOS(true)}
                className="w-full rounded-full gap-2"
              >
                <img
                  src="/assets/generated/tos-icon-transparent.dim_64x64.png"
                  alt="TOS"
                  className="h-4 w-4"
                />
                View Terms of Service
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <TOSModal open={showTOS} onClose={() => setShowTOS(false)} />
    </>
  );
}
