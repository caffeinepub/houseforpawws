import { useState } from 'react';
import { useParams, useNavigate } from '@tanstack/react-router';
import { Principal } from '@dfinity/principal';
import { useGetUserProfile, useGetFollowers, useGetFollowing, useFollowUser, useUnfollowUser, useGetAllAnimals, useGetAnimalProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { MapPin, Users, UserPlus, UserMinus, CheckCircle, ArrowLeft, MessageCircle } from 'lucide-react';
import ChatBox from '../components/ChatBox';
import AnimalCard from '../components/AnimalCard';
import AnimalDetailDialog from '../components/AnimalDetailDialog';

export default function ProfilePage() {
  const { userId } = useParams({ from: '/profile/$userId' });
  const navigate = useNavigate();
  const { identity } = useInternetIdentity();
  const userPrincipal = Principal.fromText(userId);
  const [chatOpen, setChatOpen] = useState(false);
  const [selectedAnimalId, setSelectedAnimalId] = useState<Principal | null>(null);

  const { data: profile, isLoading: profileLoading } = useGetUserProfile(userPrincipal);
  const { data: followers = [], isLoading: followersLoading } = useGetFollowers(userPrincipal);
  const { data: following = [], isLoading: followingLoading } = useGetFollowing(userPrincipal);
  const { data: allAnimals = [] } = useGetAllAnimals();
  const { data: selectedAnimal } = useGetAnimalProfile(selectedAnimalId);
  const { mutate: followUser, isPending: isFollowing } = useFollowUser();
  const { mutate: unfollowUser, isPending: isUnfollowing } = useUnfollowUser();

  const isOwnProfile = identity?.getPrincipal().toString() === userId;
  const isFollowingUser = followers.some(
    (f) => f.toString() === identity?.getPrincipal().toString()
  );

  // Filter animals posted by this user
  const userAnimals = allAnimals.filter(
    ([animalId, animal]) => animal.ownerContact.toString() === userId
  );

  const handleFollowToggle = () => {
    if (isFollowingUser) {
      unfollowUser(userPrincipal);
    } else {
      followUser(userPrincipal);
    }
  };

  const handleContactClick = () => {
    setChatOpen(true);
  };

  const getInitials = (bio: string) => {
    const words = bio.trim().split(' ');
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return bio.slice(0, 2).toUpperCase();
  };

  // Generate conversation ID between current user and profile owner
  const getConversationId = () => {
    if (!identity) return null;
    const currentUserId = identity.getPrincipal().toString();
    const otherUserId = userId;
    // Sort to ensure consistent conversation ID regardless of who initiates
    const sorted = [currentUserId, otherUserId].sort();
    return Principal.fromText(sorted[0] + sorted[1].slice(0, 10));
  };

  if (profileLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="rounded-3xl p-8 text-center">
          <p className="text-muted-foreground">Profile not found or is private</p>
          <Button onClick={() => navigate({ to: '/' })} className="mt-4 rounded-full">
            Go Home
          </Button>
        </Card>
      </div>
    );
  }

  const conversationId = getConversationId();

  return (
    <div className="container mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => navigate({ to: '/' })}
        className="mb-4 rounded-full gap-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </Button>

      <Card className="rounded-3xl overflow-hidden border-2 shadow-lg">
        <div className="h-32 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20" />
        <CardContent className="relative pt-0 pb-8">
          <div className="flex flex-col md:flex-row gap-6 items-start md:items-end -mt-16 md:-mt-12">
            <Avatar className="h-32 w-32 border-4 border-background shadow-xl">
              {profile.avatar && (
                <AvatarImage src={profile.avatar.getDirectURL()} alt="Profile" />
              )}
              <AvatarFallback className="bg-primary text-primary-foreground text-3xl">
                {getInitials(profile.bio || 'User')}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1 space-y-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-3xl font-bold">{profile.bio || 'Anonymous User'}</h1>
                  {profile.isVerified && (
                    <Badge variant="secondary" className="gap-1 rounded-full">
                      <CheckCircle className="h-3 w-3" />
                      Verified
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 mt-2 text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{profile.city}</span>
                  </div>
                  <Badge variant="outline" className="capitalize rounded-full">
                    {profile.role}
                  </Badge>
                </div>
              </div>

              <div className="flex gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="font-semibold">{followers.length}</span>
                  <span className="text-muted-foreground">Followers</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="font-semibold">{following.length}</span>
                  <span className="text-muted-foreground">Following</span>
                </div>
              </div>

              {!isOwnProfile && identity && (
                <div className="flex gap-2">
                  <Button
                    onClick={handleFollowToggle}
                    disabled={isFollowing || isUnfollowing}
                    variant={isFollowingUser ? 'outline' : 'default'}
                    className="rounded-full gap-2"
                  >
                    {isFollowingUser ? (
                      <>
                        <UserMinus className="h-4 w-4" />
                        Unfollow
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        Follow
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={handleContactClick}
                    variant="secondary"
                    className="rounded-full gap-2"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Contact
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* User's Animal Posts */}
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <span>Posts</span>
          <Badge variant="secondary" className="rounded-full">
            {userAnimals.length}
          </Badge>
        </h2>
        {userAnimals.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {userAnimals.map(([animalId, animal]) => (
              <AnimalCard
                key={animalId.toString()}
                animalId={animalId}
                animal={animal}
                onClick={() => setSelectedAnimalId(animalId)}
              />
            ))}
          </div>
        ) : (
          <Card className="rounded-3xl p-8 text-center">
            <p className="text-muted-foreground">
              {isOwnProfile ? "You haven't posted any animals yet" : "No posts yet"}
            </p>
          </Card>
        )}
      </div>

      {/* Chat Dialog */}
      {!isOwnProfile && identity && conversationId && (
        <Dialog open={chatOpen} onOpenChange={setChatOpen}>
          <DialogContent className="max-w-2xl rounded-3xl">
            <DialogHeader>
              <DialogTitle className="sr-only">Chat with {profile.bio}</DialogTitle>
            </DialogHeader>
            <ChatBox
              conversationId={conversationId}
              recipientId={userPrincipal}
              recipientName={profile.bio || 'User'}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Animal Detail Dialog */}
      {selectedAnimalId && selectedAnimal && (
        <AnimalDetailDialog
          animalId={selectedAnimalId}
          animal={selectedAnimal}
          open={!!selectedAnimalId}
          onClose={() => setSelectedAnimalId(null)}
        />
      )}
    </div>
  );
}
