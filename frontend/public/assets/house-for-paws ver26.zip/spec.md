# House for Paws

## Overview
A social platform for connecting animals in need of homes with potential adopters, featuring Instagram-like user profiles, follow functionality, and a feed-based browsing experience with identity verification.

## Core Features

### User Profiles & Social Features
- Customizable user profiles containing:
  - Avatar photo
  - Bio/description
  - City location
  - Role (owner or adopter)
- Follow/unfollow functionality between users with backend integration
- Feed-style display showing animal posts from followed users
- Profile navigation and social-style card layouts
- View Profile page displaying full user profiles with avatar, bio, city, role, and follower/following counts
- Profile viewing available for both own profile and other users' profiles
- Follow/Unfollow button on external user profiles for social interaction with real-time updates
- Contact button on user profile pages to initiate conversations about adoption with seamless chat interface integration
- User posts (animal listings) displayed directly on profile pages as shareable pastel cards in Instagram-like layout

### Animal Profiles
- Each animal has a profile containing:
  - Photo
  - Name
  - Age
  - Bio/description
  - City location
  - Posted by user information
- Animals are displayed in feed format and browsable grid/list format
- Shareable animal cards with integrated sharing functionality

### User Authentication & Verification
- Identity verification system required for users who want to:
  - Post animals for adoption
  - Contact animal owners/shelters
- Verified users can perform adoption-related actions

### Animal Posting
- Verified users can create new animal profiles by:
  - Uploading animal photos
  - Filling out animal details (name, age, bio, city)
  - Publishing the listing for public viewing and in followers' feeds
- Animal posts appear as shareable cards on user profiles

### Search & Filtering
- City-based search functionality for animals
- Filter animals by location for local discovery
- Browse all available animals
- View personalized feed of posts from followed users
- Search Profiles feature allowing users to search by name, city, or role
- Instagram-like profile cards display in search results

### Contact System & Messaging
- Interactive contact feature allowing potential adopters to reach out to:
  - Animal owners
  - Shelters
- Contact functionality only available to verified users
- Chat Box feature with live message threads per conversation
- Bubble-style UI for messaging interface
- Real-time messaging for adoption-related conversations
- Context-aware chat opening between logged-in user and profile owner
- Seamless chat interface integration from profile and animal views

### Settings & Preferences
- Settings page for managing user preferences:
  - Profile visibility settings
  - Notification preferences (mock functionality)
  - App theme selection (light/pastel variants)
- Terms of Service modal accessible from footer or settings

## UI Design
- Pastel color palette with soft, friendly aesthetics
- Rounded elements and soft typography
- Playful icons throughout the interface
- Instagram-like layout with feed-style browsing
- Charming and cute interface design
- Bubble-style messaging UI
- Cute pastel search interface
- Consistent "House for Paws" brand aesthetics with paw icons
- Shareable pastel cards for animal listings on profile pages with integrated sharing functionality
- Visual harmony maintained across all UI elements
- English language content throughout the application

## Backend Data Storage
- User profiles (avatar, bio, city, role, verification status)
- Follow relationships (followers and following lists for each user) with real-time updates
- Animal profiles (photo, name, age, bio, city, owner/shelter contact info)
- User accounts and verification status
- Contact/inquiry messages between users
- Message threads and conversation history
- User settings and preferences (profile visibility, theme preferences)
- Post sharing data and analytics

## Backend Operations
- User registration and identity verification
- User profile creation, updating (avatar, bio, city, role)
- Follow/unfollow operations between users with backend persistence
- Retrieve followers and following lists with counts and real-time updates
- Generate personalized feeds based on followed users
- Animal profile creation, updating, and deletion
- Search and filtering of animals by city
- Search users by name, city, or role
- Message handling between potential adopters and animal owners/shelters
- Real-time message thread management with seamless chat integration
- User settings management (profile visibility, preferences)
- User authentication and authorization
- Post sharing functionality and tracking
- Integration testing for contact, follow, and share features
